import Foundation
import FirebaseAuth
import FirebaseFirestore

@MainActor final class AppStore: ObservableObject {
    @Published var orders: [Order] = []
    @Published var isLoading = false
    @Published var errorMessage = ""
    private let db = Firestore.firestore()
    private var listener: ListenerRegistration?

    func startOrders() {
        listener?.remove()
        listener = db.collection("orders").addSnapshotListener { [weak self] snap, error in
            DispatchQueue.main.async {
                if let error { self?.errorMessage = error.localizedDescription; return }
                self?.orders = snap?.documents.map { Order(id: $0.documentID, data: $0.data()) }.sorted { $0.orderNumber > $1.orderNumber } ?? []
            }
        }
    }

    func stop() { listener?.remove(); listener = nil }

    func addOrder(_ order: Order) async throws {
        var new = order
        if new.orderNumber == 0 { new.orderNumber = (orders.map(\.orderNumber).max() ?? 0) + 1 }
        try await db.collection("orders").addDocument(data: new.dictionary)
    }

    func update(_ order: Order) async throws {
        guard !order.id.isEmpty else { return }
        try await db.collection("orders").document(order.id).setData(order.dictionary, merge: true)
    }

    func delete(_ order: Order) async throws {
        guard !order.id.isEmpty else { return }
        try await db.collection("orders").document(order.id).delete()
    }
}

@MainActor final class AuthStore: ObservableObject {
    @Published var user: User?
    @Published var error = ""
    @Published var loading = false
    init() { user = Auth.auth().currentUser }
    func login(email: String, password: String) async {
        loading = true; error = ""
        do { let result = try await Auth.auth().signIn(withEmail: email.trimmingCharacters(in: .whitespacesAndNewlines), password: password); user = result.user }
        catch { error = error.localizedDescription }
        loading = false
    }
    func logout() { try? Auth.auth().signOut(); user = nil }
}
