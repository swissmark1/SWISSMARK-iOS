# SWISSMARK iOS V17

This version is based on the verified V16 source archive.

Verified against the latest GitHub Actions build log:
- The actual Xcode compiler error was `OrderDetailView.swift:47:34: missing argument label 'title:' in call`.
- All `EditField` calls were corrected to use `EditField(title: ..., text: ...)`.
- The workflow no longer hardcodes V14/V15/V16 ZIP names.
- IPA artifact upload runs only after a successful build; build.log is always uploaded.

This is a source/build fix. It is not a claim that the full Android feature set has already been ported to iOS.
