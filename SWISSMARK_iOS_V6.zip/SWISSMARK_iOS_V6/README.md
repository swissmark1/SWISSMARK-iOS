# SWISSMARK iOS — final migration build

Source of truth: the supplied SWISSMARK Android project (Jetpack Compose).

Included:
- SwiftUI RTL SWISSMARK Luxury visual system
- Firebase Auth / Firestore / Storage / Messaging packages
- Live Firestore orders with the Android field names
- Role-aware navigation
- Dashboard, orders, search/filter, urgent orders, order details, add/edit, statistics
- Status history and audit log writes
- Maintenance-fee lock write
- GPS permission/current coordinate capture
- Notification permission + FCM token persistence
- Reports, customer history, storage/medias overview, blacklist, settings
- iOS build workflow via XcodeGen

Important: Apple signing/provisioning and physical-device verification must be performed on macOS with the Apple Developer account. An unsigned IPA can be built by GitHub Actions; it is not an App Store signed build.
