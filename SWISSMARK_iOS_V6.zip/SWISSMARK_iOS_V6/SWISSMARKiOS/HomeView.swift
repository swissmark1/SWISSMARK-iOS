import SwiftUI

struct MainShell: View {
    @ObservedObject var store: SwissStore
    @State private var page = "الرئيسية"
    @State private var selected: Order?
    @State private var showAdd=false
    @State private var showMenu=false
    var body: some View {
        ZStack(alignment:.leading) {
            Group { switch page {
            case "الأوردرات": OrdersPage(store:store,onOpen:{selected=$0},title:"الأوردرات")
            case "المستعجلة": OrdersPage(store:store,onOpen:{selected=$0},title:"الأوردرات المستعجلة",urgentOnly:true)
            case "الإحصائيات": StatisticsPage(store:store)
            case "المستخدمون": UsersPlaceholder(role:store.role)
            case "البلاك ليست": BlacklistPage(store:store)
            case "التقارير": ReportsPage(store:store)
            case "سجل الزبون": CustomerHistoryPage(store:store)
            case "التخزين": StoragePage(store:store)
            case "سلة المحذوفات": TrashPage()
            case "الإعدادات": SystemSettingsPage(store:store)
            default: DashboardPage(store:store,onOpen:{selected=$0},onAdd:{showAdd=true})
            } }.disabled(showMenu)
            if showMenu { Color.black.opacity(0.45).ignoresSafeArea().onTapGesture{withAnimation{showMenu=false}}; Drawer(store:store,page:$page,showMenu:$showMenu) }
        }
        .sheet(item:$selected){ OrderDetailView(order:$0,store:store) }
        .sheet(isPresented:$showAdd){ AddOrderView(store:store) }
    }
}

struct DashboardPage: View {
    @ObservedObject var store:SwissStore; var onOpen:(Order)->Void; var onAdd:()->Void
    var completed:Int { store.orders.filter{OrderStatus.completed.contains($0.status)}.count }; var urgent:Int { store.orders.filter{$0.urgent}.count }; var pending:Int { store.orders.filter{$0.status=="قيد الانتظار"}.count }
    var body:some View{ ScrollView{VStack(spacing:14){ top; hero; quick; Button(action:onAdd){HStack{Text("+").font(.largeTitle);VStack(alignment:.leading){Text("إضافة أوردر جديد").fontWeight(.bold);Text("إنشاء طلب صيانة بسرعة").font(.caption)};Spacer();Text("‹").font(.largeTitle)}.padding().background(LinearGradient(colors:[SwissColor.red,Color(red:178/255,green:14/255,blue:45/255)],startPoint:.leading,endPoint:.trailing),in:RoundedRectangle(cornerRadius:22)).foregroundStyle(.white)}; HStack{Text("نظرة سريعة").font(.title2.bold());Spacer();Text("إحصائيات مباشرة").font(.caption).foregroundStyle(.secondary)}; LazyVGrid(columns:[GridItem(.flexible()),GridItem(.flexible())],spacing:10){Metric(title:"إجمالي الأوردرات",value:store.orders.count,color:SwissColor.blue,icon:"▤");Metric(title:"مكتملة",value:completed,color:SwissColor.green,icon:"✓");Metric(title:"قيد الانتظار",value:pending,color:SwissColor.orange,icon:"◷");Metric(title:"مستعجل",value:urgent,color:SwissColor.red,icon:"!")}; HStack{Text("آخر الأوردرات").font(.title3.bold());Spacer()}; ForEach(store.orders.prefix(6)){OrderCardView(order:$0,onTap:{onOpen($0)})} }.padding(16).padding(.bottom,30)}.background(SwissColor.background.ignoresSafeArea()) }
    var top:some View{HStack{Button("☰"){}.frame(width:48,height:48).background(SwissColor.surface,in:RoundedRectangle(cornerRadius:17));Spacer();VStack(spacing:2){Text("SWISSMARK").font(.title.bold()).foregroundStyle(.white);Text("M A I N T E N A N C E").font(.system(size:8)).tracking(3).foregroundStyle(.gray)};Spacer();Text("●").frame(width:48,height:48).background(SwissColor.surface,in:RoundedRectangle(cornerRadius:17)).foregroundStyle(SwissColor.green)}.padding(.top,8)}
    var hero:some View{VStack(alignment:.trailing,spacing:6){Text("دائمًا في خدمتكم").font(.title.bold());Text("Always at Your Service").foregroundStyle(.secondary);Label("نظام الصيانة يعمل بشكل طبيعي",systemImage:"circle.fill").font(.caption).foregroundStyle(SwissColor.green)}.frame(maxWidth:.infinity,alignment:.trailing).padding(22).frame(height:180).background(LinearGradient(colors:[Color(red:12/255,green:42/255,blue:71/255),Color(red:7/255,green:18/255,blue:33/255)],startPoint:.leading,endPoint:.trailing),in:RoundedRectangle(cornerRadius:30)).overlay(RoundedRectangle(cornerRadius:30).stroke(SwissColor.blue.opacity(.45)))}
    var quick:some View{HStack{Image(systemName:"clock").font(.title2).foregroundStyle(SwissColor.blue).frame(width:48,height:48).background(SwissColor.blue.opacity(.18),in:Circle());VStack(alignment:.leading){Text("مرحباً بك").fontWeight(.bold);Text(Date.now.formatted(.dateTime.weekday(.wide).year().month().day())).font(.caption).foregroundStyle(.secondary)};Spacer();VStack(alignment:.trailing){Text("\(store.orders.count)").font(.title2.bold()).foregroundStyle(SwissColor.red);Text("أوردر").font(.caption).foregroundStyle(.secondary)}}.padding(14).swissCard()}
}

struct Metric:View{let title:String;let value:Int;let color:Color;let icon:String;var body:some View{VStack(alignment:.trailing,spacing:8){HStack{Text(icon).foregroundStyle(color);Spacer();Text("\(value)").font(.title.bold())};Text(title).font(.caption).foregroundStyle(.secondary)}.padding(16).frame(maxWidth:.infinity,minHeight:100,alignment:.trailing).swissCard()}}

struct OrdersPage: View {
    @ObservedObject var store:SwissStore; var onOpen:(Order)->Void; var title:String; var urgentOnly=false
    @State private var search=""; @State private var status="الكل"
    var list:[Order]{ store.orders.filter{(!urgentOnly || $0.urgent) && (status=="الكل" || $0.status==status) && (search.isEmpty || "\($0.orderNumber) \($0.customerName) \($0.phone) \($0.device)".localizedCaseInsensitiveContains(search))} }
    var body:some View{VStack(spacing:0){HStack{Text(title).font(.title2.bold());Spacer();Text("\(list.count)").font(.headline).foregroundStyle(SwissColor.blue)}.padding(.horizontal,16).padding(.top,18);TextField("بحث بالزبون أو الهاتف أو رقم الأوردر",text:$search).padding().swissCard().padding(16);ScrollView(.horizontal,showsIndicators:false){HStack{ForEach(["الكل"]+OrderStatus.all,id:\.self){s in Button(s){status=s}.font(.caption.bold()).padding(.horizontal,12).padding(.vertical,8).background(status==s ? SwissColor.blue : SwissColor.surface,in:Capsule()).foregroundStyle(.white)}}}.padding(.horizontal,16).padding(.bottom,10);ScrollView{LazyVStack(spacing:12){ForEach(list){OrderCardView(order:$0,onTap:{onOpen($0)})}}.padding(16)}}.background(SwissColor.background.ignoresSafeArea())}
}

struct OrderCardView: View {
    let order:Order; var onTap:()->Void
    var body:some View{Button(action:onTap){VStack(alignment:.trailing,spacing:10){HStack{if order.urgent{Text("مستعجل").font(.caption2.bold()).padding(.horizontal,8).padding(.vertical,5).background(SwissColor.red.opacity(.18),in:Capsule()).foregroundStyle(SwissColor.red)};Spacer();Text("#\(order.orderNumber)").font(.headline).foregroundStyle(SwissColor.blue);Text(order.status).font(.caption.bold()).foregroundStyle(.white).padding(.horizontal,9).padding(.vertical,5).background(statusColor,in:Capsule())};Divider().opacity(.15);info("الزبون",order.customerName);info("الهاتف",order.phone);info("الجهاز",order.device);info("العطل",order.faultType);info("المنطقة",order.region);HStack{Text(order.dateAdded.formatted(date:.numeric,time:.shortened)).font(.caption2).foregroundStyle(.secondary);Spacer();Text("تاريخ النزول").font(.caption2).foregroundStyle(.secondary)}}.padding(16).swissCard(radius:22)}.buttonStyle(.plain)}
    func info(_ k:String,_ v:String)->some View{HStack{Text(v.isEmpty ? "—" : v).font(.subheadline);Spacer();Text(k).font(.caption).foregroundStyle(.secondary)}}
    var statusColor:Color{if OrderStatus.completed.contains(order.status){return SwissColor.green};if order.status=="مؤجل"{return SwissColor.orange};if order.status=="خلل فني"{return SwissColor.red};return SwissColor.blue}
}

struct OrderDetailView: View {
    @Environment(\.dismiss) var dismiss; @ObservedObject var store:SwissStore; @State var order:Order; @State private var editing=false; @State private var saving=false; @State private var message=""
    var body:some View{NavigationStack{ScrollView{VStack(alignment:.trailing,spacing:14){HStack{Text("#\(order.orderNumber)").font(.title2.bold()).foregroundStyle(SwissColor.blue);Spacer();Text(order.status).font(.caption.bold()).padding(.horizontal,10).padding(.vertical,7).background(SwissColor.surface,in:Capsule())}; if order.urgent{Label("هذا الأوردر مستعجل",systemImage:"exclamationmark.triangle.fill").foregroundStyle(SwissColor.red).frame(maxWidth:.infinity,alignment:.trailing)}; Group{field("الزبون",$order.customerName);field("الوكيل",$order.agent);field("الهاتف",$order.phone);field("الهاتف الثاني",$order.secondPhone);field("المنطقة",$order.region);field("الجهاز",$order.device);field("نوع العطل",$order.faultType);field("الموقع",$order.customerLocation);field("الملاحظات",$order.notes)};HStack{Text("الحالة");Spacer();Menu{ForEach(OrderStatus.all,id:\.self){s in Button(s){order.status=s}}}{Text(order.status).foregroundStyle(SwissColor.blue)}}.padding().swissCard();HStack{Text("أجور الصيانة");Spacer();Text(order.maintenanceFee == 0 ? "—" : String(format:"%.0f",order.maintenanceFee))};Text("تاريخ النزول: \(order.dateAdded.formatted(date:.numeric,time:.shortened))").font(.caption).foregroundStyle(.secondary); if let d=order.completionDate{Text("تاريخ الإكمال: \(d.formatted(date:.numeric,time:.shortened))").font(.caption).foregroundStyle(.secondary)}; if !message.isEmpty{Text(message).foregroundStyle(SwissColor.green)} }.padding(16)}.background(SwissColor.background.ignoresSafeArea()).navigationTitle("تفاصيل الأوردر").toolbar{ToolbarItem(placement:.topBarTrailing){Button(editing ? "حفظ":"تعديل"){if editing{Task{saving=true;do{try await store.update(order);message="تم حفظ التعديلات"}catch{message=error.localizedDescription};saving=false}};editing.toggle()}}}.disabled(saving)} }
    @ViewBuilder func field(_ title:String,_ value:Binding<String>)->some View{if editing{TextField(title,text:value).padding().swissCard()}else{HStack{Text(value.wrappedValue.isEmpty ? "—" : value.wrappedValue);Spacer();Text(title).foregroundStyle(.secondary)}.padding().swissCard()}}
}

struct AddOrderView:View{@Environment(\.dismiss)var dismiss;@ObservedObject var store:SwissStore;@State private var o=Order();@State private var saving=false;@State private var error="";var body:some View{NavigationStack{Form{Section("بيانات العميل"){TextField("اسم العميل",text:$o.customerName);TextField("الهاتف",text:$o.phone);TextField("الهاتف الثاني",text:$o.secondPhone)};Section("الأوردر"){TextField("الوكيل",text:$o.agent);TextField("المنطقة",text:$o.region);TextField("الجهاز",text:$o.device);TextField("نوع العطل",text:$o.faultType);Toggle("مستعجل",isOn:$o.urgent);TextField("الموقع",text:$o.customerLocation);TextField("ملاحظات",text:$o.notes)};Section{Button(saving ? "جارٍ الحفظ...":"حفظ الأوردر"){Task{saving=true;do{try await store.add(o);dismiss()}catch{error=error.localizedDescription};saving=false}}}.disabled(saving);if !error.isEmpty{Text(error).foregroundStyle(.red)}}.scrollContentBackground(.hidden).background(SwissColor.background).navigationTitle("إضافة أوردر جديد").navigationBarTitleDisplayMode(.inline)}}}

struct Drawer:View{@ObservedObject var store:SwissStore;@Binding var page:String;@Binding var showMenu:Bool;var body:some View{VStack(alignment:.trailing,spacing:0){HStack{VStack(alignment:.trailing){Text("SWISSMARK").font(.title2.bold());Text(store.userName).font(.caption).foregroundStyle(.secondary);Text(store.role.displayName).font(.caption).foregroundStyle(SwissColor.red)};Spacer();Button("×"){withAnimation{showMenu=false}}}.padding();Divider();ScrollView{VStack(alignment:.trailing,spacing:5){item("الرئيسية", "house");item("الأوردرات","list.bullet.rectangle");item("المستعجلة","exclamationmark.triangle");item("الإحصائيات","chart.bar.xaxis");if store.role.canManageUsers{item("المستخدمون","person.2")};item("البلاك ليست","person.crop.circle.badge.xmark");item("التقارير","doc.text");item("سجل الزبون","person.text.rectangle");item("التخزين","externaldrive");item("سلة المحذوفات","trash");item("الإعدادات","gearshape");item("تسجيل الخروج","rectangle.portrait.and.arrow.right",logout:true)}}}.padding(.vertical,8);Spacer()}.frame(width:310).background(SwissColor.surface).ignoresSafeArea()}
func item(_ p:String,_ icon:String,logout:Bool=false)->some View{Button{if logout{store.signOut();NotificationCenter.default.post(name:.AuthStateDidChange,object:nil)}else{page=p;withAnimation{showMenu=false}}}{HStack{Image(systemName:icon).frame(width:28);Spacer();Text(p)}.padding(.horizontal,18).padding(.vertical,14).foregroundStyle(logout ? SwissColor.red : .white)}.buttonStyle(.plain)} }

struct StatisticsPage:View{@ObservedObject var store:SwissStore;var body:some View{ScrollView{VStack(spacing:12){Text("الإحصائيات").font(.largeTitle.bold()).frame(maxWidth:.infinity,alignment:.trailing);Metric(title:"إجمالي الأوردرات",value:store.orders.count,color:SwissColor.blue,icon:"▤");ForEach(OrderStatus.all,id:\.self){s in HStack{Text("\(store.orders.filter{$0.status==s}.count)").font(.headline).foregroundStyle(SwissColor.blue);Spacer();Text(s)}.padding().swissCard()}}.padding(16)}.background(SwissColor.background.ignoresSafeArea())}}

struct UsersPlaceholder:View{let role:UserRole;var body:some View{VStack(spacing:14){Text("إدارة المستخدمين").font(.largeTitle.bold());Text("الدور الحالي: \(role.displayName)");Text("هذه الواجهة مرتبطة بصلاحيات Firebase في النسخة الكاملة.").foregroundStyle(.secondary)}.padding().frame(maxWidth:.infinity,maxHeight:.infinity).background(SwissColor.background)}}
struct BlacklistPlaceholder:View{var body:some View{VStack(spacing:14){Text("البلاك ليست").font(.largeTitle.bold());Text("إدارة أرقام العملاء المحظورة").foregroundStyle(.secondary)}.frame(maxWidth:.infinity,maxHeight:.infinity).background(SwissColor.background)}}
struct SettingsPlaceholder:View{@ObservedObject var store:SwissStore;var body:some View{VStack(spacing:14){Text("الإعدادات").font(.largeTitle.bold());Text("SWISSMARK").font(.title);Button("تسجيل الخروج"){store.signOut();NotificationCenter.default.post(name:.AuthStateDidChange,object:nil)}.foregroundStyle(SwissColor.red)}.frame(maxWidth:.infinity,maxHeight:.infinity).background(SwissColor.background)}}
