import Foundation
import FirebaseAuth
import FirebaseFirestore
import FirebaseStorage
import FirebaseMessaging
import UserNotifications
import CoreLocation
import PhotosUI
import UIKit

@MainActor final class SwissStore: NSObject, ObservableObject, CLLocationManagerDelegate, MessagingDelegate {
    @Published var orders:[Order]=[]; @Published var role:UserRole=.unknown; @Published var userName=""; @Published var userEmail=""; @Published var loading=true; @Published var error=""; @Published var location=""
    private let db=Firestore.firestore(); private var orderListener:ListenerRegistration?; private var userListener:ListenerRegistration?; private let locationManager=CLLocationManager()
    override init(){super.init();locationManager.delegate=self; refreshSession(); Messaging.messaging().delegate=self }
    deinit{orderListener?.remove();userListener?.remove()}
    func refreshSession(){ guard let u=Auth.auth().currentUser else {loading=false;return}; userEmail=u.email ?? ""; userListener?.remove(); userListener=db.collection("users").document(u.uid).addSnapshotListener{[weak self] s,e in Task{@MainActor in guard let self else{return};if let e{self.error=e.localizedDescription;self.loading=false;return};let d=s?.data() ?? [:];self.role=UserRole(d["role"] as? String ?? d["userRole"] as? String);self.userName=d["name"] as? String ?? d["displayName"] as? String ?? self.userEmail;self.loading=false;self.listenOrders();self.requestNotifications()}} }
    func listenOrders(){orderListener?.remove();orderListener=db.collection("orders").whereField("deleted",isEqualTo:false).addSnapshotListener{[weak self] s,e in Task{@MainActor in if let e{self?.error=e.localizedDescription;return};self?.orders=s?.documents.compactMap(Order.init(document:)).sorted{$0.orderNumber>$1.orderNumber} ?? []}}}
    var allOrders:[Order]{orders}
    func nextOrderNumber() async throws -> Int {let r=db.collection("counters").document("orders");let d=try await r.getDocument().data();return ((d?["lastOrderNumber"] as? NSNumber)?.intValue ?? 0)+1}
    func add(_ order:Order) async throws {let n=try await nextOrderNumber();let ref=db.collection("orders").document();var d=order.dictionary;d["orderNumber"]=n;d["dateAdded"]=Int(Date().timeIntervalSince1970*1000);d["status"]="قيد الانتظار";d["deleted"]=false;try await ref.setData(d);try await db.collection("counters").document("orders").setData(["lastOrderNumber":n],merge:true);try await audit(ref,"إنشاء الأوردر")}
    func update(_ o:Order) async throws {try await db.collection("orders").document(o.id).updateData(o.dictionary);try await audit(db.collection("orders").document(o.id),"تعديل الأوردر")}
    func changeStatus(_ o:Order,_ status:String) async throws {let ref=db.collection("orders").document(o.id);let completed=OrderStatus.completed.contains(status);try await ref.updateData(["status":status,"completionDate":completed ? Int(Date().timeIntervalSince1970*1000):0]);try await ref.collection("statusHistory").addDocument(data:["from":o.status,"to":status,"at":FieldValue.serverTimestamp(),"by":userEmail]);try await audit(ref,"تغيير الحالة إلى \(status)")}
    func setUrgent(_ o:Order,_ value:Bool) async throws {try await db.collection("orders").document(o.id).updateData(["urgent":value]);try await audit(db.collection("orders").document(o.id),value ? "تعيين مستعجل":"إلغاء مستعجل")}
    func delete(_ o:Order) async throws {try await db.collection("orders").document(o.id).updateData(["deleted":true,"deletedAt":FieldValue.serverTimestamp(),"deletedBy":userEmail]);try await audit(db.collection("orders").document(o.id),"نقل إلى سلة المحذوفات")}
    func setMaintenanceFee(_ o:Order,_ fee:Double) async throws {try await db.collection("orders").document(o.id).updateData(["maintenanceFee":fee,"maintenanceFeeLocked":true,"maintenanceFeeSetBy":userEmail,"maintenanceFeeSetAt":FieldValue.serverTimestamp()]);try await audit(db.collection("orders").document(o.id),"تسجيل أجور الصيانة")}
    func requestLocation(){locationManager.requestWhenInUseAuthorization();locationManager.requestLocation()}
    func locationManager(_ manager:CLLocationManager,didUpdateLocations locations:[CLLocation]){guard let l=locations.last else{return};location="\(l.coordinate.latitude), \(l.coordinate.longitude)"}
    func locationManager(_ manager:CLLocationManager,didFailWithError error:Error){self.error=error.localizedDescription}
    func messaging(_ messaging:Messaging,didReceiveRegistrationToken fcmToken:String?){guard let t=fcmToken,let uid=Auth.auth().currentUser?.uid else{return};Task{try? await db.collection("users").document(uid).setData(["fcmToken":t],merge:true)}}
    private func requestNotifications(){UNUserNotificationCenter.current().requestAuthorization(options:[.alert,.sound,.badge]){_,_ in};UIApplication.shared.registerForRemoteNotifications()}
    private func audit(_ ref:DocumentReference,_ action:String) async throws {try await ref.collection("changeLog").addDocument(data:["action":action,"at":FieldValue.serverTimestamp(),"by":userEmail])}
    func signOut(){try? Auth.auth().signOut();orderListener?.remove();userListener?.remove();orders=[];role=.unknown;userName=""}
}

extension Order { var dictionary:[String:Any]{["customerName":customerName,"agent":agent,"phone":phone,"secondPhone":secondPhone,"region":region,"device":device,"faultType":faultType,"status":status,"dateAdded":Int(dateAdded.timeIntervalSince1970*1000),"completionDate":completionDate.map{Int($0.timeIntervalSince1970*1000)} ?? 0,"maintenanceFee":maintenanceFee,"urgent":urgent,"photos":photos,"videos":videos,"customerLocation":customerLocation,"notes":notes]} }
