import SwiftUI

enum SwissColor {
    static let background = Color(red: 2/255, green: 9/255, blue: 19/255)
    static let surface = Color(red: 16/255, green: 41/255, blue: 65/255)
    static let card = Color(red: 23/255, green: 47/255, blue: 77/255)
    static let blue = Color(red: 37/255, green: 99/255, blue: 235/255)
    static let red = Color(red: 245/255, green: 34/255, blue: 62/255)
    static let green = Color(red: 8/255, green: 185/255, blue: 104/255)
    static let orange = Color(red: 1, green: 168/255, blue: 0)
    static let purple = Color(red: 113/255, green: 56/255, blue: 232/255)
    static let cyan = Color(red: 18/255, green: 169/255, blue: 200/255)
}

extension View {
    func swissCard(radius: CGFloat = 22) -> some View {
        self.background(SwissColor.card, in: RoundedRectangle(cornerRadius: radius))
            .overlay(RoundedRectangle(cornerRadius: radius).stroke(SwissColor.blue.opacity(0.25), lineWidth: 1))
    }
}
