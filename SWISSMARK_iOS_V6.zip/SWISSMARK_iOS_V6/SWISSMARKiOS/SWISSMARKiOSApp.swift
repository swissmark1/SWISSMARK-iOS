import SwiftUI
import FirebaseCore

@main
struct SWISSMARKiOSApp: App {
    init() { FirebaseApp.configure() }
    var body: some Scene { WindowGroup { RootView() } }
}
