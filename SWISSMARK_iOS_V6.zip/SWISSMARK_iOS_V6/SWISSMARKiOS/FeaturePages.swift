import SwiftUI
import FirebaseFirestore
import FirebaseStorage
import PhotosUI
import PDFKit
import MapKit

struct ReportsPage: View { @ObservedObject var store:SwissStore; @State private var period=15; var filtered:[Order]{let cal=Calendar.current;let end=Date();let start=cal.date(byAdding:.day,value:-period,to:end)!;return store.orders.filter{$0.dateAdded>=start}}
 var body:some View{VStack{HStack{Text("التقارير").font(.largeTitle.bold());Spacer();Menu{Button("آخر 15 يوم"){period=15};Button("آخر 30 يوم"){period=30};Button("آخر 90 يوم"){period=90}}label:{Image(systemName:"calendar")}}.padding();ScrollView{VStack{Metric(title:"الأوردرات",value:filtered.count,color:SwissColor.blue,icon:"▤");Metric(title:"المكتملة",value:filtered.filter{OrderStatus.completed.contains($0.status)}.count,color:SwissColor.green,icon:"✓");Metric(title:"المستعجلة",value:filtered.filter{$0.urgent}.count,color:SwissColor.red,icon:"!");ForEach(filtered.prefix(50)){OrderCardView(order:$0,onTap:{})}}.padding()}}.background(SwissColor.background.ignoresSafeArea())}}

struct CustomerHistoryPage: View { @ObservedObject var store:SwissStore; @State var query=""; var results:[Order]{store.orders.filter{$0.customerName.localizedCaseInsensitiveContains(query)||$0.phone.contains(query)}}
 var body:some View{VStack{TextField("اسم الزبون أو الهاتف",text:$query).padding().swissCard().padding();List(results){o in VStack(alignment:.trailing){Text(o.customerName).bold();Text("#\(o.orderNumber) • \(o.status)").font(.caption);Text(o.phone).font(.caption).foregroundStyle(.secondary)}}.scrollContentBackground(.hidden).background(SwissColor.background)}}}

struct StoragePage: View { @ObservedObject var store:SwissStore; var body:some View{ScrollView{VStack(spacing:12){Text("إدارة التخزين والوسائط").font(.largeTitle.bold()).frame(maxWidth:.infinity,alignment:.trailing);Text("الصور والفيديوهات مرتبطة بكل أوردر عبر Firebase Storage.").foregroundStyle(.secondary);ForEach(store.orders.filter{!$0.photos.isEmpty || !$0.videos.isEmpty}.prefix(100)){o in HStack{Text("#\(o.orderNumber)");Spacer();Text("صور: \(o.photos.count)");Text("فيديو: \(o.videos.count)")}.padding().swissCard()}}.padding()}.background(SwissColor.background.ignoresSafeArea())}}

struct TrashPage: View { @State private var items:[Order]=[]; var body:some View{VStack{Text("سلة المحذوفات").font(.largeTitle.bold());Text("الأوردرات المحذوفة تظهر هنا للمدير.").foregroundStyle(.secondary)}.frame(maxWidth:.infinity,maxHeight:.infinity).background(SwissColor.background)}}

struct SystemSettingsPage: View { @ObservedObject var store:SwissStore; @State private var location=""; var body:some View{Form{Section("الحساب"){LabeledContent("المستخدم",value:store.userName);LabeledContent("الدور",value:store.role.displayName)};Section("الموقع"){Button("الحصول على موقعي الحالي"){store.requestLocation()};if !store.location.isEmpty{Text(store.location).textSelection(.enabled)}};Section("النظام"){Button("تسجيل الخروج",role:.destructive){store.signOut()}}}.scrollContentBackground(.hidden).background(SwissColor.background)}}

struct BlacklistPage: View { @ObservedObject var store:SwissStore; @State private var phone=""; @State private var blocked:[String]=[]; private let db=Firestore.firestore(); var body:some View{VStack{HStack{TextField("رقم الهاتف",text:$phone).keyboardType(.phonePad).padding().swissCard();Button("حظر"){if !phone.isEmpty{blocked.append(phone);phone=""}}.buttonStyle(.borderedProminent)}.padding();List(blocked,id:\.self){p in HStack{Text(p);Spacer();Button("حذف",role:.destructive){blocked.removeAll{$0==p}}}}.scrollContentBackground(.hidden).background(SwissColor.background)}.navigationTitle("البلاك ليست")}}
