import Foundation
import FirebaseFirestore

struct Order: Identifiable, Hashable {
    var id: String = UUID().uuidString
    var orderNumber: Int = 0
    var customerName = ""
    var agent = ""
    var phone = ""
    var secondPhone = ""
    var region = ""
    var device = ""
    var faultType = ""
    var status = "قيد الانتظار"
    var dateAdded: Date = .now
    var completionDate: Date?
    var maintenanceFee: Double = 0
    var urgent = false
    var photos: [String] = []
    var videos: [String] = []
    var customerLocation = ""
    var notes = ""

    init() {}
    init?(document: DocumentSnapshot) {
        guard let d = document.data() else { return nil }
        id = document.documentID
        orderNumber = Self.int(d["orderNumber"])
        customerName = d["customerName"] as? String ?? ""
        agent = d["agent"] as? String ?? ""
        phone = d["phone"] as? String ?? ""
        secondPhone = d["secondPhone"] as? String ?? ""
        region = d["region"] as? String ?? ""
        device = d["device"] as? String ?? ""
        faultType = d["faultType"] as? String ?? ""
        status = d["status"] as? String ?? "قيد الانتظار"
        dateAdded = Self.date(d["dateAdded"]) ?? .now
        completionDate = Self.date(d["completionDate"])
        maintenanceFee = Self.double(d["maintenanceFee"])
        urgent = d["urgent"] as? Bool ?? false
        photos = Self.strings(d["photos"])
        videos = Self.strings(d["videos"])
        customerLocation = d["customerLocation"] as? String ?? ""
        notes = d["notes"] as? String ?? ""
    }

    private static func int(_ v: Any?) -> Int {
        if let n = v as? NSNumber { return n.intValue }
        if let s = v as? String { return Int(s) ?? 0 }
        return 0
    }
    private static func double(_ v: Any?) -> Double {
        if let n = v as? NSNumber { return n.doubleValue }
        if let s = v as? String { return Double(s) ?? 0 }
        return 0
    }
    private static func date(_ v: Any?) -> Date? {
        if let t = v as? Timestamp { return t.dateValue() }
        if let n = v as? NSNumber { return Date(timeIntervalSince1970: n.doubleValue / 1000) }
        if let s = v as? String, let n = Double(s) { return Date(timeIntervalSince1970: n / 1000) }
        return nil
    }
    private static func strings(_ v: Any?) -> [String] {
        if let a = v as? [String] { return a }
        if let a = v as? [Any] { return a.compactMap { $0 as? String } }
        if let s = v as? String, !s.isEmpty { return [s] }
        return []
    }
}

enum UserRole: String, CaseIterable {
    case superAdmin = "Super Admin", manager = "مدير", assistant = "مساعد مدير", technician = "فني", followUp = "متابعة", unknown = "غير معروف"
    init(_ raw: String?) {
        let r = (raw ?? "").lowercased()
        switch r {
        case "superadmin", "super admin": self = .superAdmin
        case "manager", "مدير": self = .manager
        case "assistant", "assistant manager", "مساعد مدير": self = .assistant
        case "technician", "فني": self = .technician
        case "followup", "follow-up", "متابعة": self = .followUp
        default: self = .unknown
        }
    }
    var canAdd: Bool { [.superAdmin,.manager,.assistant,.technician].contains(self) }
    var canEdit: Bool { [.superAdmin,.manager,.assistant,.technician].contains(self) }
    var canManageUsers: Bool { [.superAdmin,.manager].contains(self) }
    var canDelete: Bool { [.superAdmin,.manager].contains(self) }
    var displayName: String { rawValue }
}

enum OrderStatus {
    static let all = ["قيد الانتظار","لا يرد","مؤجل","لم يكتمل","تمت الزيارة","تحت التجربة","خلل فني","مكتمل","تم في الورشة","تم الاستبدال","تم السحب","تم هاتفيا","رفض دفع أجور الصيانة"]
    static let completed = ["مكتمل","تم في الورشة","تم الاستبدال","تم هاتفيا","رفض دفع أجور الصيانة"]
}
