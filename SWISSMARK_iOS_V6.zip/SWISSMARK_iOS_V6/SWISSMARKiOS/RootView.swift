import SwiftUI
import FirebaseAuth

struct RootView: View {
    @StateObject private var store = SwissStore()
    @State private var signedIn = Auth.auth().currentUser != nil
    var body: some View {
        Group { if signedIn { MainShell(store: store) } else { LoginView { signedIn = true; store.refreshSession() } } }
            .environment(\.layoutDirection, .rightToLeft).preferredColorScheme(.dark)
            .onReceive(NotificationCenter.default.publisher(for: .AuthStateDidChange)) { _ in signedIn = Auth.auth().currentUser != nil }
    }
}

extension Notification.Name { static let AuthStateDidChange = Notification.Name("SWISSMARKAuthStateDidChange") }

struct LoginView: View {
    var onLogin: () -> Void
    @State private var email=""; @State private var password=""; @State private var error=""; @State private var busy=false
    var body: some View { ZStack { SwissColor.background.ignoresSafeArea(); VStack(spacing:18) {
        Spacer(); Text("SWISS\nMARK").font(.system(size:46,weight:.black)).multilineTextAlignment(.center).foregroundStyle(.white)
        Text("M A I N T E N A N C E").font(.caption2).tracking(3).foregroundStyle(.gray)
        VStack(spacing:12){ TextField("البريد الإلكتروني",text:$email).textInputAutocapitalization(.never).keyboardType(.emailAddress).padding().swissCard(); SecureField("كلمة المرور",text:$password).padding().swissCard() }
        Button { busy=true; Auth.auth().signIn(withEmail:email.trimmingCharacters(in:.whitespacesAndNewlines),password:password){_,e in busy=false; if let e { error=e.localizedDescription } else { onLogin() } } } label: { Text(busy ? "جارٍ الدخول..." : "تسجيل الدخول").frame(maxWidth:.infinity).padding() }.disabled(busy).background(SwissColor.red,in:RoundedRectangle(cornerRadius:18)).foregroundStyle(.white).fontWeight(.bold)
        if !error.isEmpty { Text(error).foregroundStyle(SwissColor.red).font(.footnote).multilineTextAlignment(.center) }; Spacer()
    }.padding(24) } }
}
