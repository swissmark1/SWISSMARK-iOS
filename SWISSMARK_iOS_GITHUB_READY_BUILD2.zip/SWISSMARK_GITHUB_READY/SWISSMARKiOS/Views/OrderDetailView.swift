import UIKit
import SwiftUI
struct OrderDetailView: View { @EnvironmentObject var store:Store; @State var order:Order; @State private var editing=false
 var body:some View{ScrollView{VStack(spacing:14){ title; info; actions; history }.padding()}.smBackground().navigationTitle("تفاصيل الأوردر") }
 var title:some View{VStack{Text(order.customer).font(.title2.bold());Text("أوردر #\(order.number)").foregroundStyle(.secondary);Text(order.status).font(.headline).foregroundStyle(Color.smBlue)}}
 var info:some View{VStack(alignment:.leading,spacing:10){row("الوكيل",order.agent);row("الهاتف",order.phone);row("هاتف ثاني",order.secondPhone);row("المنطقة",order.region);row("الجهاز",order.device);row("نوع العطل",order.fault);row("أجور الصيانة",order.fees.isEmpty ? "غير محددة" : order.fees);row("الموقع",order.location.isEmpty ? "غير محدد" : order.location);row("ملاحظات",order.notes.isEmpty ? "لا توجد" : order.notes)}.frame(maxWidth:.infinity,alignment:.leading).smCard()}
 func row(_ a:String,_ b:String)->some View{HStack{Text(a).foregroundStyle(.secondary);Spacer();Text(b).foregroundStyle(Color.smText)}}
 var actions:some View{VStack(spacing:10){Button("تغيير الحالة"){var x=order;x.status="مكتمل";x.completedAt = .now;x.history.append(.init(status:x.status,user:store.user.name));store.update(x);order=x}.buttonStyle(.borderedProminent);HStack{Button("اتصال") { if let u = URL(string: "tel:\(order.phone)") { UIApplication.shared.open(u) } }; Button("واتساب") { if let u = URL(string: "https://wa.me/\(order.phone.filter { $0.isNumber })") { UIApplication.shared.open(u) } }}.buttonStyle(.bordered)}}
 var history:some View{VStack(alignment:.leading){Text("سجل التغييرات").font(.headline);ForEach(order.history){h in HStack{Text(h.status);Spacer();Text(h.user).foregroundStyle(.secondary);Text(h.date,style:.date).foregroundStyle(.secondary)}}}.frame(maxWidth:.infinity,alignment:.leading).smCard()}
}
