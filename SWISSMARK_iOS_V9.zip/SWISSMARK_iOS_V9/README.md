# SWISSMARK iOS V8

This version is a substantive SwiftUI migration base derived from the original Android SWISSMARK model and navigation structure.

Included:
- Arabic RTL UI and Android-inspired luxury colors
- Firebase Authentication login
- Firestore real-time orders
- Add, search, filter by status, order details, status updates, delete
- Dashboard statistics
- Reports and maintenance-fee summary
- Drawer navigation for the major Android feature areas
- GoogleService-Info.plist

The original Android project remains the source of truth for additional feature parity.
