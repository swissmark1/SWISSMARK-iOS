import Foundation
import FirebaseFirestore

struct Order: Identifiable, Hashable {
    var id: String = ""
    var orderNumber: Int = 0
    var customerName: String = ""
    var agent: String = ""
    var phone: String = ""
    var secondPhone: String = ""
    var region: String = ""
    var device: String = ""
    var faultType: String = ""
    var status: String = "قيد الانتظار"
    var dateAdded: Date = .now
    var completionDate: Date?
    var maintenanceFee: Double = 0
    var urgent: Bool = false
    var photos: [String] = []
    var videos: [String] = []
    var customerLocation: String = ""
    var notes: String = ""

    init(id: String = "", data: [String: Any] = [:]) {
        self.id = id
        orderNumber = data["orderNumber"] as? Int ?? Int(data["orderNumber"] as? String ?? "0") ?? 0
        customerName = data["customerName"] as? String ?? data["customer"] as? String ?? ""
        agent = data["agent"] as? String ?? ""
        phone = data["phone"] as? String ?? ""
        secondPhone = data["secondPhone"] as? String ?? ""
        region = data["region"] as? String ?? ""
        device = data["device"] as? String ?? ""
        faultType = data["faultType"] as? String ?? data["fault"] as? String ?? ""
        status = data["status"] as? String ?? "قيد الانتظار"
        if let t = data["dateAdded"] as? Timestamp { dateAdded = t.dateValue() }
        else if let t = data["createdAt"] as? Timestamp { dateAdded = t.dateValue() }
        if let t = data["completionDate"] as? Timestamp { completionDate = t.dateValue() }
        maintenanceFee = data["maintenanceFee"] as? Double ?? Double(data["maintenanceFee"] as? Int ?? 0)
        urgent = data["urgent"] as? Bool ?? false
        photos = data["photos"] as? [String] ?? data["photoUrls"] as? [String] ?? []
        videos = data["videos"] as? [String] ?? data["videoUrls"] as? [String] ?? []
        customerLocation = data["customerLocation"] as? String ?? data["location"] as? String ?? ""
        notes = data["notes"] as? String ?? ""
    }

    var dictionary: [String: Any] {
        ["orderNumber": orderNumber, "customerName": customerName, "agent": agent, "phone": phone,
         "secondPhone": secondPhone, "region": region, "device": device, "faultType": faultType,
         "status": status, "dateAdded": Timestamp(date: dateAdded), "maintenanceFee": maintenanceFee,
         "urgent": urgent, "photos": photos, "videos": videos, "customerLocation": customerLocation, "notes": notes]
    }
}

let orderStatuses = ["قيد الانتظار","لا يرد","مؤجل","لم يكتمل","تمت الزيارة","تحت التجربة","خلل فني","مكتمل","تم في الورشة","تم الاستبدال","تم هاتفيا","رفض دفع أجور الصيانة"]
