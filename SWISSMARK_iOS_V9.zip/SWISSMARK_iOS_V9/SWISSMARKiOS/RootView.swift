import SwiftUI

struct LoginView: View {
    @EnvironmentObject var auth: AuthStore
    @State private var email = ""
    @State private var password = ""
    var body: some View {
        ZStack {
            Color.swissBG.ignoresSafeArea()
            ScrollView {
                VStack(spacing: 18) {
                    Spacer(minLength: 50)
                    HStack(spacing: 0) { Text("SWISS").foregroundStyle(.white); Text("MARK").foregroundStyle(.red) }
                        .font(.system(size: 42, weight: .black, design: .rounded))
                    Text("M A I N T E N A N C E").font(.caption).tracking(5).foregroundStyle(.secondary)
                    Text("نظام إدارة الصيانة").font(.title.bold()).foregroundStyle(Color.swissText)
                    VStack(spacing: 12) {
                        TextField("البريد الإلكتروني", text: $email).textInputAutocapitalization(.never).keyboardType(.emailAddress).textFieldStyle(.roundedBorder)
                        SecureField("كلمة المرور", text: $password).textFieldStyle(.roundedBorder)
                        if !auth.error.isEmpty { Text(auth.error).font(.footnote).foregroundStyle(.red).multilineTextAlignment(.center) }
                        Button { Task { await auth.login(email: email, password: password) } } label: {
                            HStack { if auth.loading { ProgressView().tint(.white) }; Text(auth.loading ? "جاري الدخول..." : "تسجيل الدخول").font(.headline) }
                                .frame(maxWidth: .infinity).frame(height: 54)
                        }.buttonStyle(.borderedProminent).tint(.swissBlue).disabled(auth.loading)
                    }.padding(22).background(Color.swissCard).clipShape(RoundedRectangle(cornerRadius: 22))
                    Spacer(minLength: 50)
                }.padding(22)
            }
        }
    }
}

struct MainView: View {
    @EnvironmentObject var auth: AuthStore
    @EnvironmentObject var store: AppStore
    @State private var selected: AppSection = .home
    @State private var drawer = false
    var body: some View {
        ZStack(alignment: .leading) {
            NavigationStack { content.navigationTitle(selected.title).toolbar { ToolbarItem(placement: .topBarLeading) { Button { withAnimation { drawer.toggle() } } label: { Image(systemName: "line.3.horizontal") } } } }
            if drawer { Color.black.opacity(0.45).ignoresSafeArea().onTapGesture { withAnimation { drawer = false } }; DrawerView(selected: $selected, close: { withAnimation { drawer = false } }, logout: auth.logout).frame(width: 300).transition(.move(edge: .leading)) }
        }.onAppear { store.startOrders() }
    }
    @ViewBuilder private var content: some View {
        switch selected {
        case .home: HomeView(selected: $selected)
        case .orders: OrdersView()
        case .urgent: OrdersView(urgentOnly: true)
        case .search: SearchView()
        case .add: AddOrderView()
        case .statistics: StatisticsView()
        case .reports: ReportsView()
        case .fees: FeesView()
        case .blacklist: SimpleFeatureView(title: "القائمة السوداء", icon: "person.crop.circle.badge.xmark", description: "البحث عن الزبائن المحظورين وإدارة الموافقات")
        case .customers: SimpleFeatureView(title: "سجل الزبائن", icon: "person.2", description: "البحث بالاسم أو رقم الهاتف")
        case .users: SimpleFeatureView(title: "إدارة المستخدمين", icon: "person.badge.key", description: "إدارة حسابات الموظفين والصلاحيات")
        case .media: SimpleFeatureView(title: "إدارة الوسائط", icon: "photo.on.rectangle", description: "إدارة الصور والفيديوهات المرتبطة بالأوردرات")
        case .trash: SimpleFeatureView(title: "سلة المحذوفات", icon: "trash", description: "مراجعة واستعادة الأوردرات المحذوفة")
        case .chat: SimpleFeatureView(title: "المحادثة", icon: "message", description: "المراسلة داخل النظام")
        case .settings: SimpleFeatureView(title: "إعدادات النظام", icon: "gearshape", description: "إعدادات التطبيق والنظام")
        }
    }
}

enum AppSection: String, CaseIterable { case home, orders, urgent, search, add, statistics, reports, fees, blacklist, customers, users, media, trash, chat, settings
    var title: String { switch self { case .home:"الرئيسية"; case .orders:"الأوردرات"; case .urgent:"الأوردرات المستعجلة"; case .search:"البحث"; case .add:"إضافة أوردر"; case .statistics:"الإحصائيات"; case .reports:"التقارير"; case .fees:"الأجور"; case .blacklist:"القائمة السوداء"; case .customers:"سجل الزبائن"; case .users:"المستخدمين"; case .media:"الوسائط"; case .trash:"سلة المحذوفات"; case .chat:"المحادثة"; case .settings:"الإعدادات" } }
    var icon: String { switch self { case .home:"house.fill"; case .orders:"list.clipboard"; case .urgent:"exclamationmark.triangle.fill"; case .search:"magnifyingglass"; case .add:"plus.circle.fill"; case .statistics:"chart.bar.fill"; case .reports:"doc.text.fill"; case .fees:"banknote.fill"; case .blacklist:"person.crop.circle.badge.xmark"; case .customers:"person.2.fill"; case .users:"person.badge.key.fill"; case .media:"photo.on.rectangle.angled"; case .trash:"trash.fill"; case .chat:"message.fill"; case .settings:"gearshape.fill" } }
}

struct DrawerView: View {
    @Binding var selected: AppSection; let close: () -> Void; let logout: () -> Void
    var body: some View { VStack(alignment: .leading, spacing: 8) {
        HStack { Text("SWISS").foregroundStyle(.white); Text("MARK").foregroundStyle(.red) }.font(.title.bold()).padding(.horizontal,16).padding(.top,60)
        Text("نظام إدارة الصيانة").font(.caption).foregroundStyle(.secondary).padding(.horizontal,16).padding(.bottom,12)
        ScrollView { ForEach(AppSection.allCases, id: \.self) { s in Button { selected = s; close() } label: { Label(s.title, systemImage: s.icon).frame(maxWidth:.infinity,alignment:.leading).padding(13).background(selected == s ? Color.swissBlue.opacity(0.35) : .clear).clipShape(RoundedRectangle(cornerRadius: 12)) } } }.padding(.horizontal,10)
        Spacer(); Button { logout(); close() } label: { Label("تسجيل الخروج", systemImage:"rectangle.portrait.and.arrow.right").foregroundStyle(.red).padding(16) }
    }.foregroundStyle(.white).frame(maxHeight:.infinity).background(Color.swissBG).shadow(radius:20) }
}
