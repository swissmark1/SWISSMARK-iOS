import SwiftUI
import FirebaseCore

@main struct SWISSMARKiOSApp: App {
    @StateObject private var auth = AuthStore()
    @StateObject private var store = AppStore()
    init() { FirebaseApp.configure() }
    var body: some Scene {
        WindowGroup {
            Group {
                if auth.user == nil { LoginView() } else { MainView() }
            }
            .environmentObject(auth).environmentObject(store)
            .environment(\.layoutDirection, .rightToLeft)
            .preferredColorScheme(.dark)
        }
    }
}
