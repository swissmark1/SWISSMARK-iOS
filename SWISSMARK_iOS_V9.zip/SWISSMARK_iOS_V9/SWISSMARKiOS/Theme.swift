import SwiftUI

extension Color {
    static let swissBG = Color(red: 6/255, green: 20/255, blue: 38/255)
    static let swissCard = Color(red: 23/255, green: 47/255, blue: 77/255)
    static let swissBlue = Color(red: 37/255, green: 99/255, blue: 235/255)
    static let swissGreen = Color(red: 8/255, green: 185/255, blue: 104/255)
    static let swissOrange = Color(red: 1, green: 168/255, blue: 0)
    static let swissRed = Color(red: 245/255, green: 34/255, blue: 62/255)
    static let swissPurple = Color(red: 113/255, green: 56/255, blue: 232/255)
    static let swissCyan = Color(red: 18/255, green: 169/255, blue: 200/255)
    static let swissText = Color(red: 234/255, green: 240/255, blue: 1)
}

struct SwissCard: ViewModifier {
    func body(content: Content) -> some View {
        content.padding(16).background(Color.swissCard).clipShape(RoundedRectangle(cornerRadius: 18))
    }
}
extension View { func swissCard() -> some View { modifier(SwissCard()) } }

struct StatusBadge: View {
    let status: String
    var color: Color {
        switch status {
        case "مكتمل", "تم في الورشة", "تم الاستبدال", "تم هاتفيا": return .swissGreen
        case "لا يرد", "مؤجل": return .swissOrange
        case "خلل فني", "لم يكتمل": return .swissRed
        case "تحت التجربة", "تمت الزيارة": return .swissCyan
        default: return .swissBlue
        }
    }
    var body: some View { Text(status).font(.caption.bold()).foregroundStyle(.white).padding(.horizontal,10).padding(.vertical,6).background(color).clipShape(Capsule()) }
}
