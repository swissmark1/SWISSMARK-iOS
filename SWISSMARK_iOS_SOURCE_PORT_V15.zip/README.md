# SWISSMARK iOS — source-grounded port

This project was generated from the verified Android SWISSMARK source archive.

Verified Android source facts used here:
- Order fields: orderNumber, customerName, agent, phone, secondPhone, region, device, faultType, status, dateAdded, completionDate, maintenanceFee, urgent, photos, videos, customerLocation, notes.
- Statuses and completed statuses were copied from MainActivity.kt.
- Roles were copied from MainActivity.kt.
- The Swiss Blue palette was copied from ThemeController.palette("swiss_blue").
- The luxury home and order-card structure follows HomePageLuxury, OrdersPage, and OrderCard.

This is a source-grounded iOS UI/data port, not a claim that every Android backend feature is already implemented.
Firebase/Auth/Firestore/Storage/FCM, Backblaze video, GPS/Waze, PDF, reports, chat and server-side permissions still require their iOS service implementations.
