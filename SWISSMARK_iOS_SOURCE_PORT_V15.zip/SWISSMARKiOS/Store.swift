import Combine

import Foundation

@MainActor
final class AppStore: ObservableObject {
    @Published var isLoggedIn = false
    @Published var userName = "SWISSMARK"
    @Published var role: UserRole = .manager
    @Published var orders: [Order] = []
    @Published var selectedPage = "الرئيسية"
    @Published var drawerOpen = false
    @Published var selectedOrder: Order?

    init() {
        orders = [
            Order(id: "1", orderNumber: 4606, customerName: "زبون تجريبي", agent: "SWISSMARK",
                  phone: "07700000000", secondPhone: "", region: "بغداد", device: "غسالة",
                  faultType: "عطل فني", status: "قيد الانتظار", dateAdded: nowMillis(),
                  completionDate: 0, maintenanceFee: 0, urgent: true, photos: [], videos: [],
                  customerLocation: "", notes: "أوردر من بيانات العرض"),
            Order(id: "2", orderNumber: 4605, customerName: "عميل آخر", agent: "فني",
                  phone: "07800000000", secondPhone: "", region: "الكرادة", device: "ثلاجة",
                  faultType: "لا تعمل", status: "مكتمل", dateAdded: nowMillis() - 86400000,
                  completionDate: nowMillis() - 3600000, maintenanceFee: 25000, urgent: false,
                  photos: [], videos: [], customerLocation: "", notes: "")
        ]
    }

    func addOrder(_ order: Order) {
        orders.insert(order, at: 0)
    }

    func updateOrder(_ order: Order) {
        guard let i = orders.firstIndex(where: {$0.id == order.id}) else { return }
        orders[i] = order
    }

    var completed: Int { orders.filter { swissCompletedStatuses.contains($0.status) }.count }
    var waiting: Int { orders.filter { $0.status == "قيد الانتظار" }.count }
    var urgent: Int { orders.filter(\.urgent).count }
    var noAnswer: Int { orders.filter { $0.status == "لا يرد" }.count }
    var postponed: Int { orders.filter { $0.status == "مؤجل" }.count }
}

func nowMillis() -> Int64 { Int64(Date().timeIntervalSince1970 * 1000) }

func swissDate(_ millis: Int64) -> String {
    guard millis > 0 else { return "غير محدد" }
    let d = Date(timeIntervalSince1970: TimeInterval(millis) / 1000)
    let f = DateFormatter()
    f.locale = Locale(identifier: "en_US_POSIX")
    f.dateFormat = "yyyy-MM-dd | HH:mm"
    return f.string(from: d)
}
