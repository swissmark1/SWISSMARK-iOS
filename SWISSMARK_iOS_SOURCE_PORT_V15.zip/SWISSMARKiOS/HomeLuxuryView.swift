
import SwiftUI

struct HomeLuxuryView: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                topBar
                hero
                stats
                recent
                Spacer(minLength: 100)
            }
            .padding(.bottom, 20)
        }
        .background(SwissTheme.background.ignoresSafeArea())
        .safeAreaInset(edge: .bottom) { bottomBar }
    }

    private var topBar: some View {
        HStack {
            Button { withAnimation { store.drawerOpen = true } } label: {
                Image(systemName: "line.3.horizontal")
                    .font(.title2.bold()).foregroundStyle(.white)
                    .frame(width: 48, height: 48)
                    .background(Color(hex: "102941"))
                    .clipShape(RoundedRectangle(cornerRadius: 17))
            }
            Spacer()
            VStack(spacing: 1) {
                HStack(spacing: 0) {
                    Text("SWISS").foregroundStyle(.white)
                    Text("MARK").foregroundStyle(SwissTheme.red)
                }.font(.system(size: 26, weight: .black))
                Text("M A I N T E N A N C E").font(.system(size: 8, weight: .bold))
                    .tracking(3).foregroundStyle(SwissTheme.muted)
            }
            Spacer()
            Circle().fill(Color(hex: "102941")).frame(width: 48, height: 48)
                .overlay(Image(systemName: "person.fill").foregroundStyle(.white))
        }
        .padding(.horizontal, 18).padding(.top, 14)
    }

    private var hero: some View {
        VStack(alignment: .trailing, spacing: 10) {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text("اليوم").font(.caption).foregroundStyle(SwissTheme.muted)
                    Text("\(store.orders.count)").font(.system(size: 34, weight: .black)).foregroundStyle(.white)
                    Text("أوردر").font(.caption).foregroundStyle(SwissTheme.muted)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 4) {
                    Text("مرحباً بك").font(.headline).foregroundStyle(.white)
                    Text("نظام إدارة الصيانة").font(.subheadline).foregroundStyle(SwissTheme.muted)
                    Text("SWISSMARK").font(.title.bold()).foregroundStyle(SwissTheme.red)
                }
            }
            Button { store.selectedPage = "إضافة أوردر جديد" } label: {
                Text("+  إضافة أوردر جديد").fontWeight(.bold)
                    .frame(maxWidth: .infinity).padding(.vertical, 13)
            }
            .background(SwissTheme.blue).foregroundStyle(.white)
            .clipShape(RoundedRectangle(cornerRadius: 16))
        }
        .padding(20)
        .background(
            LinearGradient(colors: [Color(hex:"0C2A47"), Color(hex:"071A2C"), Color(hex:"071221")],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
        )
        .overlay(RoundedRectangle(cornerRadius: 30).stroke(SwissTheme.blue.opacity(0.45)))
        .clipShape(RoundedRectangle(cornerRadius: 30))
        .padding(.horizontal, 18)
    }

    private var stats: some View {
        VStack(alignment: .trailing, spacing: 10) {
            Text("إحصائيات الأوردرات").font(.title3.bold()).foregroundStyle(.white)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                HomeStat(title: "جميع الأوردرات", value: "\(store.orders.count)", color: SwissTheme.blue)
                HomeStat(title: "مكتملة", value: "\(store.completed)", color: SwissTheme.green)
                HomeStat(title: "قيد الانتظار", value: "\(store.waiting)", color: SwissTheme.orange)
                HomeStat(title: "مستعجلة", value: "\(store.urgent)", color: SwissTheme.red)
                HomeStat(title: "لا يرد", value: "\(store.noAnswer)", color: SwissTheme.purple)
                HomeStat(title: "مؤجلة", value: "\(store.postponed)", color: SwissTheme.cyan)
            }
        }
        .padding(.horizontal, 18)
    }

    private var recent: some View {
        VStack(alignment: .trailing, spacing: 10) {
            Text("آخر الأوردرات").font(.title3.bold()).foregroundStyle(.white)
            ForEach(Array(store.orders.prefix(4))) { order in
                OrderCard(order: order) { store.selectedOrder = order }
            }
        }
        .padding(.horizontal, 18)
    }

    private var bottomBar: some View {
        HStack {
            BottomItem(title: "حسابي", icon: "person") {}
            BottomItem(title: "الإحصائيات", icon: "chart.bar") { store.selectedPage = "الإحصائيات" }
            BottomItem(title: "الرئيسية", icon: "house.fill") { store.selectedPage = "الرئيسية" }
            BottomItem(title: "الأوردرات", icon: "doc.text") { store.selectedPage = "الأوردرات" }
        }
        .padding(10).background(SwissTheme.card).clipShape(RoundedRectangle(cornerRadius: 20))
        .padding(.horizontal, 12).padding(.bottom, 6)
    }
}

struct HomeStat: View {
    let title: String; let value: String; let color: Color
    var body: some View {
        VStack(alignment: .trailing, spacing: 5) {
            Text(value).font(.system(size: 28, weight: .black)).foregroundStyle(.white)
            Text(title).font(.caption.bold()).foregroundStyle(.white)
        }
        .frame(maxWidth: .infinity, minHeight: 88, alignment: .trailing)
        .padding(14).background(color.opacity(0.9))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

struct BottomItem: View {
    let title: String; let icon: String; let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: icon)
                Text(title).font(.system(size: 10, weight: .bold))
            }.foregroundStyle(.white.opacity(0.85)).frame(maxWidth: .infinity)
        }
    }
}
