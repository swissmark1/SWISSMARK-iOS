
import SwiftUI

struct SwissPalette {
    let background: Color
    let card: Color
    let primary: Color
    let green: Color
    let orange: Color
    let red: Color
    let purple: Color
    let cyan: Color
    let lightCard: Color
}

enum SwissTheme {
    static let swissBlue = SwissPalette(
        background: Color(hex: "061426"),
        card: Color(hex: "172F4D"),
        primary: Color(hex: "2563EB"),
        green: Color(hex: "08B968"),
        orange: Color(hex: "FFA800"),
        red: Color(hex: "F5223E"),
        purple: Color(hex: "7138E8"),
        cyan: Color(hex: "12A9C8"),
        lightCard: Color(hex: "EAF0FF")
    )

    static let emerald = SwissPalette(
        background: Color(hex: "071713"),
        card: Color(hex: "12352C"),
        primary: Color(hex: "10B981"),
        green: Color(hex: "22C55E"),
        orange: Color(hex: "F59E0B"),
        red: Color(hex: "EF4444"),
        purple: Color(hex: "8B5CF6"),
        cyan: Color(hex: "06B6D4"),
        lightCard: Color(hex: "E8FFF7")
    )

    static let background = Color(hex: "020913")
    static let deep = Color(hex: "061526")
    static let card = Color(hex: "122E50")
    static let innerCard = Color(hex: "0A1F36")
    static let blue = Color(hex: "2563EB")
    static let green = Color(hex: "08B968")
    static let orange = Color(hex: "FFA800")
    static let red = Color(hex: "F5223E")
    static let purple = Color(hex: "7138E8")
    static let cyan = Color(hex: "12A9C8")
    static let lightText = Color(hex: "EAF0FF")
    static let muted = Color(hex: "8FA8C0")
}

extension Color {
    init(hex: String) {
        let clean = hex.replacingOccurrences(of: "#", with: "")
        let value = UInt64(clean, radix: 16) ?? 0
        self.init(
            red: Double((value >> 16) & 0xFF) / 255,
            green: Double((value >> 8) & 0xFF) / 255,
            blue: Double(value & 0xFF) / 255
        )
    }
}
