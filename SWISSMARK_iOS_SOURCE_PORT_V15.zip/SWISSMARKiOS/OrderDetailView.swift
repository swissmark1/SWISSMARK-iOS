
import SwiftUI

struct OrderDetailView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State var order: Order
    @State private var edit = false
    @State private var fee = ""
    @State private var notes = ""

    init(order: Order) {
        _order = State(initialValue: order)
        _fee = State(initialValue: order.maintenanceFee == 0 ? "" : String(order.maintenanceFee))
        _notes = State(initialValue: order.notes)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                Header(title: "تفاصيل الأوردر #\(order.orderNumber)")
                HStack {
                    Button("← رجوع") { dismiss() }
                    Spacer()
                    if store.role.canEditOrder {
                        Button(edit ? "إلغاء التعديل" : "✏️ تعديل الأوردر") { edit.toggle() }
                    }
                }
                .foregroundStyle(SwissTheme.blue).padding(.horizontal, 18)

                VStack(alignment: .trailing, spacing: 10) {
                    Text(order.customerName).font(.title2.bold()).foregroundStyle(.white)
                    InfoLine(icon: "phone", label: "الهاتف", value: order.phone)
                    InfoLine(icon: "person", label: "الوكيل", value: order.agent)
                    InfoLine(icon: "mappin", label: "المنطقة", value: order.region)
                    InfoLine(icon: "square.grid.2x2", label: "الجهاز", value: order.device)
                    InfoLine(icon: "wrench.and.screwdriver", label: "العطل", value: order.faultType)
                    InfoLine(icon: "calendar", label: "تاريخ النزول", value: swissDate(order.dateAdded))
                    InfoLine(icon: "flag", label: "الحالة", value: order.status)
                }
                .padding(18).frame(maxWidth: .infinity, alignment: .trailing)
                .background(SwissTheme.card).clipShape(RoundedRectangle(cornerRadius: 22))
                .padding(.horizontal, 18)

                if edit {
                    VStack(spacing: 10) {
                        EditField("اسم الزبون", text: $order.customerName)
                        EditField("الهاتف", text: $order.phone)
                        EditField("الهاتف الثاني", text: $order.secondPhone)
                        EditField("الوكيل / الفني", text: $order.agent)
                        EditField("المنطقة", text: $order.region)
                        EditField("الجهاز", text: $order.device)
                        EditField("نوع العطل", text: $order.faultType)
                    }.padding(.horizontal, 18)
                }

                VStack(alignment: .trailing, spacing: 8) {
                    Text("الحالة").font(.headline).foregroundStyle(.white)
                    Menu {
                        ForEach(swissStatuses, id: \.self) { s in
                            Button(s) { order.status = s }
                        }
                    } label: {
                        HStack { Text(order.status); Spacer(); Image(systemName: "chevron.down") }
                            .foregroundStyle(.white).padding()
                            .background(SwissTheme.innerCard)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    Toggle("🚨 مستعجل", isOn: $order.urgent).tint(SwissTheme.red)
                }.padding(.horizontal, 18)

                VStack(alignment: .trailing, spacing: 8) {
                    Text("أجور الصيانة").font(.headline).foregroundStyle(.white)
                    TextField("0", text: $fee).keyboardType(.decimalPad)
                        .padding().background(SwissTheme.innerCard)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .foregroundStyle(.white)
                    Text("الملاحظات").font(.headline).foregroundStyle(.white)
                    TextEditor(text: $notes).frame(minHeight: 110)
                        .padding(8).background(SwissTheme.innerCard)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }.padding(.horizontal, 18)

                Button {
                    order.maintenanceFee = Double(fee) ?? 0
                    order.notes = notes
                    store.updateOrder(order)
                    dismiss()
                } label: {
                    Text("حفظ التعديلات").fontWeight(.bold).frame(maxWidth: .infinity).padding()
                }
                .background(SwissTheme.blue).foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .padding(.horizontal, 18)
            }.padding(.bottom, 30)
        }
        .background(SwissTheme.deep.ignoresSafeArea())
    }
}

struct EditField: View {
    let title: String
    @Binding var text: String
    var body: some View {
        VStack(alignment: .trailing, spacing: 5) {
            Text(title).font(.caption).foregroundStyle(SwissTheme.muted)
            TextField(title, text: $text).padding(13)
                .background(SwissTheme.innerCard).clipShape(RoundedRectangle(cornerRadius: 14))
                .foregroundStyle(.white)
        }
    }
}
