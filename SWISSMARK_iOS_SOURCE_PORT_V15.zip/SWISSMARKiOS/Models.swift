
import Foundation
import SwiftUI

enum UserRole: String, CaseIterable {
    case superAdmin = "SUPER_ADMIN"
    case manager = "MANAGER"
    case assistantManager = "ASSISTANT_MANAGER"
    case technician = "TECHNICIAN"
    case followUp = "FOLLOW_UP"
    case unknown = "UNKNOWN"

    var displayName: String {
        switch self {
        case .superAdmin: return "Super Admin"
        case .manager: return "مدير"
        case .assistantManager: return "مساعد مدير"
        case .technician: return "فني"
        case .followUp: return "متابعة"
        case .unknown: return "غير معروف"
        }
    }

    var canAddOrder: Bool {
        self == .superAdmin || self == .manager || self == .assistantManager || self == .followUp
    }

    var canEditOrder: Bool {
        self == .superAdmin || self == .manager || self == .assistantManager || self == .technician
    }

    var canManageUsers: Bool { self == .superAdmin || self == .manager }
    var canManageBlacklist: Bool { self == .superAdmin || self == .manager }
    var canViewBlacklist: Bool { self != .unknown }
    var canEditNotes: Bool { self != .unknown }
    var canManageSystem: Bool { self == .superAdmin || self == .manager }
}

struct StatusHistory: Identifiable, Hashable {
    let id: String
    let fromStatus: String
    let toStatus: String
    let changedBy: String
    let changedByEmail: String
    let changedAt: Int64
}

struct Order: Identifiable, Hashable {
    let id: String
    var orderNumber: Int
    var customerName: String
    var agent: String
    var phone: String
    var secondPhone: String
    var region: String
    var device: String
    var faultType: String
    var status: String
    var dateAdded: Int64
    var completionDate: Int64
    var maintenanceFee: Double
    var urgent: Bool
    var photos: [String]
    var videos: [String]
    var customerLocation: String
    var notes: String
}

struct Expense: Identifiable, Hashable {
    let id: String
    var title: String
    var amount: Double
    var date: Int64
    var notes: String
}

let swissStatuses = [
    "قيد الانتظار",
    "مكتمل",
    "تم السحب",
    "لا يرد",
    "مؤجل",
    "تم في الورشة",
    "تم الاستبدال",
    "تمت الزيارة",
    "تحت التجربة",
    "تم هاتفياً",
    "رفض الصيانة",
    "رفض دفع الأجور"
]

let swissCompletedStatuses: Set<String> = [
    "مكتمل", "تم في الورشة", "تم الاستبدال",
    "تحت التجربة", "تم هاتفياً", "رفض دفع الأجور"
]
