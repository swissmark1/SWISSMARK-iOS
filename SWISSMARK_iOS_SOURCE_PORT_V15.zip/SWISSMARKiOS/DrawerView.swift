
import SwiftUI

struct DrawerView: View {
    @EnvironmentObject var store: AppStore

    let pages = [
        "الرئيسية", "الأوردرات", "المستعجلة", "البحث", "سجل الزبون",
        "الفلترة", "الإحصائيات", "التقارير", "التقارير السابقة",
        "إنشاء أجور الصيانة", "الأجور المستحصلة", "المشتريات والمصاريف",
        "البلاك ليست", "المستخدمون والصلاحيات", "طلبات حذف الأوردرات",
        "إدارة الوسائط", "التخزين", "سلة المحذوفات", "تغيير كلمة المرور",
        "الدردشة", "إعدادات النظام"
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .trailing, spacing: 8) {
                HStack {
                    VStack(alignment: .trailing) {
                        Text("SWISSMARK").font(.system(size: 28, weight: .bold)).foregroundStyle(.white)
                        Text("نظام إدارة الصيانة").foregroundStyle(SwissTheme.muted)
                    }
                    Spacer()
                    Button("×") { store.drawerOpen = false }
                        .font(.largeTitle).foregroundStyle(.white)
                }

                VStack(alignment: .trailing, spacing: 3) {
                    Text(store.userName).font(.headline).foregroundStyle(.white)
                    Text(store.role.displayName).font(.subheadline).foregroundStyle(SwissTheme.muted)
                }
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(14).background(SwissTheme.card)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .padding(.top, 10)

                ForEach(pages, id: \.self) { page in
                    Button {
                        if page == "إضافة أوردر جديد" { return }
                        store.selectedPage = page
                        store.drawerOpen = false
                    } label: {
                        HStack {
                            Image(systemName: icon(page))
                            Text(page).fontWeight(.bold)
                            Spacer()
                        }
                        .foregroundStyle(store.selectedPage == page ? SwissTheme.blue : .white)
                        .padding(13)
                        .background(store.selectedPage == page ? SwissTheme.blue.opacity(0.13) : .clear)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                }

                Divider().overlay(SwissTheme.muted)
                Button {
                    store.isLoggedIn = false
                    store.drawerOpen = false
                } label: {
                    HStack {
                        Image(systemName: "rectangle.portrait.and.arrow.right")
                        Text("تسجيل الخروج").fontWeight(.bold)
                        Spacer()
                    }.foregroundStyle(SwissTheme.red).padding(13)
                }
            }
            .padding(18)
        }
        .background(SwissTheme.deep.ignoresSafeArea())
    }

    private func icon(_ page: String) -> String {
        switch page {
        case "الرئيسية": return "house"
        case "الأوردرات": return "doc.text"
        case "المستعجلة": return "exclamationmark.triangle"
        case "البحث": return "magnifyingglass"
        case "الإحصائيات": return "chart.bar"
        case "التقارير", "التقارير السابقة": return "doc.richtext"
        case "البلاك ليست": return "person.crop.circle.badge.xmark"
        case "المستخدمون والصلاحيات": return "person.2"
        case "سلة المحذوفات": return "trash"
        case "الدردشة": return "message"
        case "إعدادات النظام": return "gearshape"
        default: return "square.grid.2x2"
        }
    }
}
