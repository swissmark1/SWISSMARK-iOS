
import SwiftUI

struct MainShell: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        ZStack(alignment: .leading) {
            NavigationStack {
                page
                    .toolbar(.hidden, for: .navigationBar)
            }
            if store.drawerOpen {
                Color.black.opacity(0.58)
                    .ignoresSafeArea()
                    .onTapGesture { withAnimation { store.drawerOpen = false } }
                DrawerView()
                    .frame(maxWidth: 350)
                    .transition(.move(edge: .leading))
                    .zIndex(10)
            }
        }
        .background(SwissTheme.background)
    }

    @ViewBuilder
    private var page: some View {
        switch store.selectedPage {
        case "الرئيسية": HomeLuxuryView()
        case "الأوردرات": OrdersView()
        case "المستعجلة": OrdersView(filter: "مستعجلة")
        case "الإحصائيات": StatisticsView()
        case "إضافة أوردر جديد": AddOrderView()
        default: PlaceholderView(title: store.selectedPage)
        }
    }
}
