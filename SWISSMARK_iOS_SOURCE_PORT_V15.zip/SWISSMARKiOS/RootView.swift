
import SwiftUI

struct RootView: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        Group {
            if store.isLoggedIn {
                MainShell()
            } else {
                LoginView()
            }
        }
    }
}

struct LoginView: View {
    @EnvironmentObject var store: AppStore
    @State private var username = ""
    @State private var password = ""

    var body: some View {
        ZStack {
            SwissTheme.background.ignoresSafeArea()
            VStack(spacing: 18) {
                Text("SWISS").font(.system(size: 40, weight: .black)).foregroundStyle(.white)
                Text("MARK").font(.system(size: 40, weight: .black)).foregroundStyle(SwissTheme.red)
                Text("M A I N T E N A N C E").font(.caption.bold()).tracking(3).foregroundStyle(SwissTheme.muted)
                VStack(spacing: 12) {
                    TextField("اسم المستخدم", text: $username)
                        .textInputAutocapitalization(.never)
                        .padding().background(SwissTheme.innerCard).clipShape(RoundedRectangle(cornerRadius: 14))
                    SecureField("كلمة المرور", text: $password)
                        .padding().background(SwissTheme.innerCard).clipShape(RoundedRectangle(cornerRadius: 14))
                    Button {
                        store.isLoggedIn = true
                        store.userName = username.isEmpty ? "SWISSMARK" : username
                    } label: {
                        Text("تسجيل الدخول").fontWeight(.bold).frame(maxWidth: .infinity).padding()
                    }
                    .background(SwissTheme.blue).foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .padding(22)
                .background(SwissTheme.card)
                .clipShape(RoundedRectangle(cornerRadius: 24))
            }
            .padding(22)
        }
    }
}
