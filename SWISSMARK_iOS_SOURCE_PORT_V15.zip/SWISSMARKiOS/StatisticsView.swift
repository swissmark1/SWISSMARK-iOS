
import SwiftUI

struct StatisticsView: View {
    @EnvironmentObject var store: AppStore
    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                Header(title: "الإحصائيات")
                StatRow(title: "جميع الأوردرات", value: store.orders.count, color: SwissTheme.blue)
                StatRow(title: "مكتملة", value: store.completed, color: SwissTheme.green)
                StatRow(title: "قيد الانتظار", value: store.waiting, color: SwissTheme.orange)
                StatRow(title: "مستعجلة", value: store.urgent, color: SwissTheme.red)
                StatRow(title: "لا يرد", value: store.noAnswer, color: SwissTheme.purple)
                StatRow(title: "مؤجلة", value: store.postponed, color: SwissTheme.cyan)
            }.padding(.bottom, 30)
        }.background(SwissTheme.deep.ignoresSafeArea())
    }
}

struct StatRow: View {
    let title: String; let value: Int; let color: Color
    var body: some View {
        HStack {
            Text("\(value)").font(.system(size: 30, weight: .black)).foregroundStyle(.white)
            Spacer()
            Text(title).font(.headline.bold()).foregroundStyle(.white)
        }.padding(18).background(color.opacity(0.88))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .padding(.horizontal, 18)
    }
}
