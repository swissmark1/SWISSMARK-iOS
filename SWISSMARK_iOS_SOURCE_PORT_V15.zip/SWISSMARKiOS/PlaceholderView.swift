
import SwiftUI

struct PlaceholderView: View {
    let title: String
    var body: some View {
        VStack(spacing: 14) {
            Header(title: title)
            Text(title).font(.title.bold()).foregroundStyle(.white)
            Text("هذه الشاشة موجودة في بنية تطبيق Android الأصلي، وسيتم ربطها بخدماتها عند استكمال طبقة البيانات.")
                .multilineTextAlignment(.center)
                .foregroundStyle(SwissTheme.muted)
                .padding()
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(SwissTheme.deep.ignoresSafeArea())
    }
}
