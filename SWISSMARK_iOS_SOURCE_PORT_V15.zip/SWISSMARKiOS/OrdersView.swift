
import SwiftUI

struct OrdersView: View {
    @EnvironmentObject var store: AppStore
    var filter: String? = nil
    @State private var search = ""

    var displayed: [Order] {
        var result = store.orders
        if filter == "مستعجلة" { result = result.filter(\.urgent) }
        let q = search.trimmingCharacters(in: .whitespacesAndNewlines)
        if !q.isEmpty {
            result = result.filter {
                "\($0.orderNumber)".contains(q) ||
                $0.customerName.localizedCaseInsensitiveContains(q) ||
                $0.phone.contains(q) ||
                $0.secondPhone.contains(q)
            }
        }
        return result
    }

    var title: String {
        filter == "مستعجلة" ? "الأوردرات المستعجلة" : "الأوردرات"
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                Header(title: title)
                HStack {
                    VStack(alignment: .trailing) {
                        Text("عدد الأوردرات").font(.caption).foregroundStyle(SwissTheme.muted)
                        Text("\(displayed.count)").font(.system(size: 27, weight: .black)).foregroundStyle(.white)
                    }
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    .padding(14).background(SwissTheme.card)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    Button { store.selectedPage = "إضافة أوردر جديد" } label: {
                        Text("+ إضافة أوردر").fontWeight(.bold).frame(maxWidth: .infinity)
                    }
                    .frame(height: 64).background(SwissTheme.blue).foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                }
                .padding(.horizontal, 18)

                TextField("ابحث برقم الأوردر أو اسم الزبون أو الهاتف...", text: $search)
                    .padding(14).background(SwissTheme.innerCard)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 18)

                LazyVStack(spacing: 12) {
                    ForEach(displayed) { order in
                        OrderCard(order: order) { store.selectedOrder = order }
                    }
                }
                .padding(.horizontal, 18)
                Spacer(minLength: 30)
            }
        }
        .background(SwissTheme.deep.ignoresSafeArea())
        .navigationDestination(item: $store.selectedOrder) { order in
            OrderDetailView(order: order)
        }
    }
}

struct Header: View {
    @EnvironmentObject var store: AppStore
    let title: String
    var body: some View {
        HStack {
            Button { withAnimation { store.drawerOpen = true } } label: {
                Image(systemName: "line.3.horizontal").font(.title2.bold())
                    .foregroundStyle(.white)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2) {
                Text(title).font(.title3.bold()).foregroundStyle(.white)
                Text("SWISSMARK").font(.caption.bold()).foregroundStyle(SwissTheme.red)
            }
        }.padding(.horizontal, 18).padding(.top, 14)
    }
}

struct OrderCard: View {
    let order: Order
    let onClick: () -> Void

    var statusColor: Color {
        if order.urgent { return SwissTheme.red }
        if swissCompletedStatuses.contains(order.status) { return SwissTheme.green }
        switch order.status {
        case "قيد الانتظار": return SwissTheme.orange
        case "لا يرد": return SwissTheme.purple
        case "مؤجل", "تمت الزيارة": return SwissTheme.cyan
        case "تم السحب": return SwissTheme.purple
        default: return SwissTheme.blue
        }
    }

    var statusIcon: String {
        if order.urgent { return "🚨" }
        if swissCompletedStatuses.contains(order.status) { return "✓" }
        switch order.status {
        case "قيد الانتظار": return "◷"
        case "لا يرد": return "☎"
        case "مؤجل": return "…"
        case "تمت الزيارة": return "⌖"
        case "تم السحب": return "↙"
        default: return "•"
        }
    }

    var body: some View {
        Button(action: onClick) {
            VStack(spacing: 10) {
                HStack {
                    Text("\(statusIcon)  \(order.status)")
                        .font(.caption.bold()).foregroundStyle(statusColor)
                        .padding(.horizontal, 12).padding(.vertical, 8)
                        .background(statusColor.opacity(0.16))
                        .overlay(Capsule().stroke(statusColor.opacity(0.5)))
                        .clipShape(Capsule())
                    Spacer()
                    Text("#\(String(format: "%04d", order.orderNumber))")
                        .font(.system(size: 24, weight: .black)).foregroundStyle(.white)
                }

                Divider().overlay(Color(hex: "29425F"))

                VStack(spacing: 1) {
                    InfoLine(icon: "clock", label: "تاريخ النزول", value: swissDate(order.dateAdded))
                    if swissCompletedStatuses.contains(order.status) {
                        InfoLine(icon: "checkmark", label: "تاريخ الإكمال", value: swissDate(order.completionDate))
                    }
                    InfoLine(icon: "person", label: "الزبون", value: order.customerName.isEmpty ? "غير محدد" : order.customerName)
                    InfoLine(icon: "phone", label: "الهاتف", value: order.phone.isEmpty ? "غير محدد" : order.phone)
                    InfoLine(icon: "square.grid.2x2", label: "الجهاز", value: order.device.isEmpty ? "غير محدد" : order.device)
                    InfoLine(icon: "wrench.and.screwdriver", label: "العطل", value: order.faultType.isEmpty ? "غير محدد" : order.faultType)
                    InfoLine(icon: "mappin.and.ellipse", label: "المنطقة", value: order.region.isEmpty ? "غير محددة" : order.region)
                }
                .padding(12).background(SwissTheme.innerCard)
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color(hex: "294866")))
                .clipShape(RoundedRectangle(cornerRadius: 20))
            }
            .padding(15)
            .background(LinearGradient(colors: [SwissTheme.card, Color(hex:"0B2038")], startPoint: .top, endPoint: .bottom))
            .overlay(RoundedRectangle(cornerRadius: 26).stroke(statusColor.opacity(0.24)))
            .clipShape(RoundedRectangle(cornerRadius: 26))
        }
        .buttonStyle(.plain)
    }
}

struct InfoLine: View {
    let icon: String; let label: String; let value: String
    var body: some View {
        HStack(spacing: 8) {
            Text(value).font(.subheadline).foregroundStyle(.white).lineLimit(2)
            Spacer()
            Image(systemName: icon).foregroundStyle(SwissTheme.muted)
            Text(label).font(.caption).foregroundStyle(SwissTheme.muted)
        }.padding(.vertical, 5)
    }
}
