import UIKit

import SwiftUI

struct AddOrderView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var customer = ""
    @State private var agent = ""
    @State private var phone = ""
    @State private var secondPhone = ""
    @State private var region = ""
    @State private var device = ""
    @State private var fault = ""
    @State private var notes = ""
    @State private var location = ""
    @State private var urgent = false

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                Header(title: "إضافة أوردر جديد")
                formField("اسم الزبون", $customer)
                formField("الوكيل / الفني", $agent)
                formField("رقم الهاتف", $phone, keyboard: .phonePad)
                formField("الهاتف الثاني", $secondPhone, keyboard: .phonePad)
                formField("المنطقة", $region)
                formField("الجهاز", $device)
                formField("نوع العطل", $fault)
                formField("الموقع", $location)
                VStack(alignment: .trailing, spacing: 8) {
                    Text("الملاحظات").foregroundStyle(.white).fontWeight(.bold)
                    TextEditor(text: $notes).frame(minHeight: 100)
                        .padding(8).background(SwissTheme.innerCard)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .padding(.horizontal, 18)
                Toggle(isOn: $urgent) {
                    Text("🚨 مستعجل").foregroundStyle(.white).fontWeight(.bold)
                }
                .tint(SwissTheme.red).padding(.horizontal, 18)

                Button {
                    let next = (store.orders.map(\.orderNumber).max() ?? 0) + 1
                    let order = Order(
                        id: UUID().uuidString, orderNumber: next, customerName: customer,
                        agent: agent, phone: phone, secondPhone: secondPhone, region: region,
                        device: device, faultType: fault, status: "قيد الانتظار",
                        dateAdded: nowMillis(), completionDate: 0, maintenanceFee: 0,
                        urgent: urgent, photos: [], videos: [], customerLocation: location, notes: notes
                    )
                    store.addOrder(order)
                    store.selectedPage = "الأوردرات"
                    dismiss()
                } label: {
                    Text("حفظ الأوردر").fontWeight(.bold).frame(maxWidth: .infinity).padding()
                }
                .background(SwissTheme.blue).foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .padding(18)
            }
        }
        .background(SwissTheme.deep.ignoresSafeArea())
    }

    private func formField(_ title: String, _ value: Binding<String>, keyboard: UIKeyboardType = .default) -> some View {
        VStack(alignment: .trailing, spacing: 6) {
            Text(title).font(.caption.bold()).foregroundStyle(SwissTheme.muted)
            TextField(title, text: value).keyboardType(keyboard)
                .padding(13).background(SwissTheme.innerCard)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .foregroundStyle(.white)
        }.padding(.horizontal, 18)
    }
}
