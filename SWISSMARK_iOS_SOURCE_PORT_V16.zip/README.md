# SWISSMARK iOS V16

This package is based on the inspected SWISSMARK iOS V15 source.

V16 changes the GitHub Actions workflow so it does not hard-code V14/V15.
It discovers the SWISSMARK_iOS_SOURCE_PORT_*.zip archive in the repository,
extracts it when needed, generates the Xcode project with XcodeGen, builds
the iOS target, verifies the Mach-O executable, and packages the IPA.

Swift source files were syntax-checked before this package was produced.
A successful GitHub Actions `xcodebuild` run is still required to validate
the complete iOS/Xcode toolchain build.
