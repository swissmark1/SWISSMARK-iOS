import SwiftUI
struct GenericPage: View { let title:String; let items:[String]; var body:some View{List(items,id:\.self){Text($0).foregroundStyle(Color.smText)}.scrollContentBackground(.hidden).background(Color.smBg).navigationTitle(title)} }
struct StatisticsView:View{ @EnvironmentObject var store:Store; var body:some View{ScrollView{VStack(spacing:12){Text("إحصائيات الصيانة").font(.title.bold());ForEach(AppStatus.all,id:\.self){s in HStack{Text(s);Spacer();Text("\(store.orders.filter{$0.status==s}.count)").bold()}.smCard()}}.padding()}.smBackground()}}
