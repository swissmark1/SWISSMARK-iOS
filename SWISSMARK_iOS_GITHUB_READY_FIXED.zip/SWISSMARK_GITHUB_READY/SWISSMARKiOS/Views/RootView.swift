import SwiftUI
struct RootView: View {
    @StateObject private var store = Store()
    var body: some View { Group { if store.loggedIn { MainView().environmentObject(store) } else { LoginView().environmentObject(store) } }.environment(\.layoutDirection, .rightToLeft) }
}
struct LoginView: View {
    @EnvironmentObject var store: Store
    @State private var u=""; @State private var p=""
    var body: some View { VStack(spacing:20) { Spacer(); Text("SWISSMARK").font(.system(size:38,weight:.black)).foregroundStyle(Color.smText); Text("نظام إدارة الصيانة").foregroundStyle(.secondary); TextField("اسم المستخدم",text:$u).textFieldStyle(.roundedBorder); SecureField("كلمة المرور",text:$p).textFieldStyle(.roundedBorder); Button("دخول") { Task { _ = await store.login(username:u,password:p) } }.buttonStyle(.borderedProminent).frame(maxWidth:.infinity); Spacer() }.padding(28).smBackground() }
}
