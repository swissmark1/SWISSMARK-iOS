import SwiftUI
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore
import FirebaseStorage
import FirebaseMessaging

@main
struct SWISSMARKiOSApp: App {
    init() {
        if FirebaseApp.app() == nil { FirebaseApp.configure() }
    }
    var body: some Scene { WindowGroup { RootView() } }
}
