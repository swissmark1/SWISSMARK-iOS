import SwiftUI
extension Color {
    static let smBg = Color(red: 6/255, green: 20/255, blue: 38/255)
    static let smCard = Color(red: 23/255, green: 47/255, blue: 77/255)
    static let smBlue = Color(red: 37/255, green: 99/255, blue: 235/255)
    static let smGreen = Color(red: 8/255, green: 185/255, blue: 104/255)
    static let smOrange = Color(red: 1, green: 168/255, blue: 0)
    static let smRed = Color(red: 245/255, green: 34/255, blue: 62/255)
    static let smPurple = Color(red: 113/255, green: 56/255, blue: 232/255)
    static let smCyan = Color(red: 18/255, green: 169/255, blue: 200/255)
    static let smText = Color(red: 234/255, green: 240/255, blue: 1)
}
struct SMBackground: ViewModifier { func body(content: Content) -> some View { ZStack { Color.smBg.ignoresSafeArea(); content } } }
extension View { func smBackground() -> some View { modifier(SMBackground()) } }
struct SMCard: ViewModifier { func body(content: Content) -> some View { content.padding(14).background(Color.smCard).clipShape(RoundedRectangle(cornerRadius: 18)).overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.06))) } }
extension View { func smCard() -> some View { modifier(SMCard()) } }
