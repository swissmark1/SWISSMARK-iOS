import Foundation
import FirebaseFirestore
import FirebaseAuth
import FirebaseStorage

@MainActor final class Store: ObservableObject {
    @Published var orders: [Order] = []
    @Published var user: AppUser = .init(id: "local", name: "SWISSMARK", username: "manager", role: "مدير")
    @Published var loggedIn = false
    @Published var loading = false
    private let db = Firestore.firestore()
    init() { loadLocal(); listen() }
    func login(username: String, password: String) async -> Bool {
        if username.isEmpty || password.isEmpty { return false }
        loggedIn = true; return true
    }
    func logout() { loggedIn = false }
    func add(_ order: Order) { orders.insert(order, at: 0); saveLocal() }
    func update(_ order: Order) { if let i = orders.firstIndex(where: {$0.id == order.id}) { orders[i] = order; saveLocal() } }
    func delete(_ order: Order) { orders.removeAll{$0.id == order.id}; saveLocal() }
    private func saveLocal() { if let d = try? JSONEncoder().encode(orders) { UserDefaults.standard.set(d, forKey: "orders") } }
    private func loadLocal() { if let d = UserDefaults.standard.data(forKey: "orders"), let x = try? JSONDecoder().decode([Order].self, from:d) { orders=x } }
    private func listen() { /* Firestore listener is attached after iOS Firebase config is supplied. */ }
}
