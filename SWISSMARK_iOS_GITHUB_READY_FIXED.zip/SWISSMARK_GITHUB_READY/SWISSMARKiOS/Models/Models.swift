import Foundation

struct Order: Identifiable, Codable {
    var id: String = UUID().uuidString
    var number: String = ""
    var customer: String = ""
    var agent: String = ""
    var phone: String = ""
    var secondPhone: String = ""
    var region: String = ""
    var device: String = ""
    var fault: String = ""
    var status: String = "قيد الانتظار"
    var createdAt: Date = .now
    var completedAt: Date? = nil
    var fees: String = ""
    var urgent: Bool = false
    var location: String = ""
    var notes: String = ""
    var images: [String] = []
    var videos: [String] = []
    var technician: String = ""
    var history: [StatusEvent] = []
}
struct StatusEvent: Codable, Identifiable {
    var id = UUID().uuidString
    var status: String
    var user: String
    var date: Date = .now
}
struct AppUser: Identifiable, Codable {
    var id: String
    var name: String
    var username: String
    var role: String
    var active: Bool = true
}

enum AppStatus {
    static let all = ["قيد الانتظار","لا يرد","مؤجل","لم يكتمل","تمت الزيارة","تحت التجربة","خلل فني","مكتمل","تم في الورشة","تم الاستبدال","تم هاتفيا","تم السحب","رفض دفع أجور الصيانة"]
    static let closed = ["مكتمل","تم في الورشة","تم الاستبدال","تم هاتفيا","رفض دفع أجور الصيانة"]
}
