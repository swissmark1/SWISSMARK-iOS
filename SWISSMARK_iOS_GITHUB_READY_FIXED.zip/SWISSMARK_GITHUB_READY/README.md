# SWISSMARK iOS

مشروع iOS مبني على مشروع Android الأصلي لـ SWISSMARK، مع SwiftUI وFirebase.

## الرفع إلى GitHub
ارفع محتويات هذا المجلد إلى مستودع `SWISSMARK-iOS` على فرع `main`.

بعد الرفع شغّل GitHub Actions من:
**Actions → SWISSMARK iOS Build → Run workflow**

الـworkflow يولد مشروع Xcode بواسطة XcodeGen، يثبت Firebase، ثم يبني Archive ويضع IPA كـArtifact.

Bundle ID: `com.swissmark.ios`
Minimum iOS: 16.0
