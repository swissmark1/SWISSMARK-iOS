# V51 porting matrix

Core:
- Authentication -> Firebase Auth
- Orders -> Firestore
- Order status/history/audit -> Firestore subcollections
- Users/roles -> Firestore + Auth
- Customer registry -> Firestore
- Blacklist -> Firestore
- Media -> iOS image/video picker + existing backend endpoints
- Location -> Core Location via Flutter geolocator
- Waze/phone/WhatsApp -> URL launcher
- Reports -> PDF generation layer
- Notifications -> Firebase Cloud Messaging
- Google Sheets -> existing Web App endpoint
- Video -> existing Cloudflare/Backblaze worker endpoint

The real Firebase project configuration and signing credentials are intentionally not embedded.
