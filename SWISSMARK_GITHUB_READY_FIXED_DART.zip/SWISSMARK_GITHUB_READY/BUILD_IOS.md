# Build SWISS MARK iOS / IPA

On Windows:
- `flutter pub get`
- develop/test the Flutter source.
- keep the real Firebase iOS plist out of public repositories.

For the final iOS build, use a macOS runner or Mac:
1. `flutter pub get`
2. `cd ios && pod install && cd ..`
3. Open `ios/Runner.xcworkspace` in Xcode.
4. Select the Runner target and configure Signing/Bundle Identifier.
5. Confirm `GoogleService-Info.plist` is in the Runner target.
6. Test on a physical iPhone.
7. Archive/export the app using the signing method appropriate to the user's distribution certificate.

TrollStore installation is a separate device/distribution step; it does not replace the iOS build/signing process.
