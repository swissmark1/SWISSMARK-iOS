# Firebase iOS setup for SWISS MARK

1. Open the existing SWISS MARK Firebase project in Firebase Console.
2. Add an iOS app using the exact bundle identifier you choose for SWISS MARK.
3. Download `GoogleService-Info.plist`.
4. Place it in `ios/Runner/GoogleService-Info.plist`.
5. Open the project on macOS in Xcode and make sure the plist is included in the Runner target.
6. Enable Push Notifications and Background Modes > Remote notifications if SWISS MARK notifications are required.
7. Confirm Firestore/Auth rules are the same backend rules used by the Android app.

Do not put service-account JSON files or private server keys in the iOS app.
