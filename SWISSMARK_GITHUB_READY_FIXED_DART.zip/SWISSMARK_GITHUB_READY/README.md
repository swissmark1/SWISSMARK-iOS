# SWISSMARK iOS - Complete Feature Build

This project is the iOS/Flutter implementation base for SWISS MARK V51.

Included:
- Firebase Authentication / Firestore integration points
- Orders, status history, audit log
- Roles and role-aware UI hooks
- Search and order details
- Customer registry
- Blacklist
- Expenses
- Media area
- Reports area
- Recycle bin
- Location/Waze/call/share hooks
- Urgent orders
- Maintenance fee
- Arabic UI

Before iOS build:
1. Run `flutter pub get`.
2. Add the real Firebase iOS configuration (`GoogleService-Info.plist`) from the same Firebase project.
3. Run `flutterfire configure` if you use FlutterFire CLI, or configure Firebase manually.
4. Build on macOS/Xcode or a macOS CI runner for an iOS IPA.
5. Backblaze/Cloudflare video upload and Google Sheets endpoints from V51 must be ported as server-side services; secrets must not be embedded in the iOS app.
