# SWISSMARK — GitHub iOS Build

هذا المشروع مجهز ليُبنى على GitHub Actions باستخدام جهاز macOS.

## التشغيل
1. ارفع كامل محتويات المشروع إلى مستودع GitHub.
2. افتح تبويب **Actions**.
3. اختر **Build SWISSMARK iOS IPA**.
4. اضغط **Run workflow**.
5. بعد اكتمال البناء، افتح نتيجة التشغيل وحمّل artifact باسم **SWISSMARK-IPA**.
6. الملف الناتج اسمه `SWISSMARK.ipa`.

البناء هنا يتم بدون توقيع Apple (`--no-codesign`) ثم يتم تغليف التطبيق كـ IPA. تثبيته بواسطة TrollStore يعتمد على توافق جهازك وإصدار iOS مع TrollStore.

## ملاحظة مهمة
ملف Firebase الخاص بـ iOS (`GoogleService-Info.plist`) غير مضاف لأن كل مشروع Firebase يحتاج ملفه الخاص. إذا كان التطبيق يعتمد على Firebase في التشغيل، يجب وضع الملف داخل `ios/Runner/GoogleService-Info.plist` قبل البناء أو إضافته من خلال Secret/Artifact workflow.
