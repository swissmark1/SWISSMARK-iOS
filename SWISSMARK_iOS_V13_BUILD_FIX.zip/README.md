# SWISSMARK iOS

This project is the first real SwiftUI port based on the original Android SWISSMARK UI and data model.

Reference source:
- Original Android MainActivity.kt
- Original SWISSMARK order/status structure
- Original dark/luxury palette

Current scope:
- Login shell
- Home/dashboard
- Orders/search/status filters
- Order details
- Add order
- Statistics
- Drawer/navigation
- Arabic RTL UI
- SWISSMARK colors and card styling

Firebase/iOS signing are intentionally not faked. The iOS Firebase plist and Apple signing credentials must be connected before production deployment.
