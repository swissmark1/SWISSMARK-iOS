
import SwiftUI

struct DrawerView: View {
    @EnvironmentObject var store: AppStore
    var body: some View {
        VStack(alignment: .trailing, spacing: 0) {
            VStack(alignment: .trailing, spacing: 5) {
                Text("SWISSMARK").font(.system(size: 30, weight: .black)).foregroundStyle(.white)
                Text("MAINTENANCE").font(.caption.bold()).foregroundStyle(SwissTheme.blue)
                Text(store.userName).font(.subheadline).foregroundStyle(.white.opacity(0.7))
            }
            .frame(maxWidth: .infinity, alignment: .trailing)
            .padding(24)
            .background(SwissTheme.card)

            ScrollView {
                VStack(spacing: 8) {
                    DrawerButton(title: "الرئيسية", icon: "house.fill") { close(); store.selectedTab = "الرئيسية" }
                    DrawerButton(title: "الأوردرات", icon: "doc.text") { close(); store.selectedTab = "الأوردرات" }
                    DrawerButton(title: "المستعجلة", icon: "exclamationmark.triangle.fill") { close() }
                    DrawerButton(title: "بحث", icon: "magnifyingglass") { close() }
                    DrawerButton(title: "فلتر", icon: "line.3.horizontal.decrease.circle") { close() }
                    DrawerButton(title: "الإحصائيات", icon: "chart.bar.fill") { close(); store.selectedTab = "الإحصائيات" }
                    DrawerButton(title: "أجور الصيانة", icon: "banknote") { close() }
                    DrawerButton(title: "التقارير", icon: "doc.richtext") { close() }
                    DrawerButton(title: "المستخدمون والصلاحيات", icon: "person.2.fill") { close() }
                    DrawerButton(title: "القائمة السوداء", icon: "nosign") { close() }
                    DrawerButton(title: "سجل التغييرات", icon: "clock.arrow.circlepath") { close() }
                    DrawerButton(title: "الإعدادات", icon: "gearshape.fill") { close() }
                }
                .padding(16)
            }

            Button {
                store.loggedIn = false
                store.drawerOpen = false
            } label: {
                HStack {
                    Image(systemName: "rectangle.portrait.and.arrow.right")
                    Text("تسجيل الخروج").fontWeight(.bold)
                    Spacer()
                }
                .foregroundStyle(SwissTheme.red)
                .padding(18)
                .background(SwissTheme.card)
                .clipShape(RoundedRectangle(cornerRadius: 15))
            }
            .padding(16)
        }
        .background(SwissTheme.background)
        .ignoresSafeArea()
    }

    private func close() { withAnimation { store.drawerOpen = false } }
}

struct DrawerButton: View {
    let title: String; let icon: String; let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon).frame(width: 25)
                Text(title).fontWeight(.medium)
                Spacer()
            }
            .foregroundStyle(.white)
            .padding(15)
            .background(SwissTheme.card.opacity(0.7))
            .clipShape(RoundedRectangle(cornerRadius: 14))
        }
    }
}
