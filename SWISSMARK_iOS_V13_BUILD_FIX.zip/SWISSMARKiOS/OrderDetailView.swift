
import SwiftUI

struct OrderDetailView: View {
    @EnvironmentObject var store: AppStore
    let orderID: String
    var order: Order? { store.orders.first(where: { $0.id == orderID }) }
    var body: some View {
        ScrollView {
            if let order {
                VStack(spacing: 14) {
                    HeaderView(title: "تفاصيل الأوردر")
                    VStack(spacing: 8) {
                        Text("#\(order.number)").font(.system(size: 30, weight: .black)).foregroundStyle(.white)
                        Text(order.status.rawValue).font(.headline.bold()).foregroundStyle(statusColor(order.status))
                        if order.urgent { Text("مستعجل").font(.caption.bold()).foregroundStyle(.white).padding(.horizontal, 12).padding(.vertical, 6).background(SwissTheme.red).clipShape(Capsule()) }
                    }
                    .frame(maxWidth: .infinity).padding(20).background(SwissTheme.card).clipShape(RoundedRectangle(cornerRadius: 22))

                    DetailSection(title: "بيانات الزبون") {
                        InfoRow(title: "اسم الزبون", value: order.customer)
                        InfoRow(title: "الهاتف", value: order.phone)
                        if !order.secondPhone.isEmpty { InfoRow(title: "هاتف ثاني", value: order.secondPhone) }
                        InfoRow(title: "المنطقة", value: order.region)
                    }
                    DetailSection(title: "بيانات الجهاز") {
                        InfoRow(title: "الجهاز", value: order.device)
                        InfoRow(title: "نوع العطل", value: order.fault)
                        InfoRow(title: "الفني", value: order.technician)
                    }
                    DetailSection(title: "الأجور والتاريخ") {
                        InfoRow(title: "أجور الصيانة", value: order.fee > 0 ? "\(Int(order.fee)) د.ع" : "غير محددة")
                        InfoRow(title: "تاريخ الإضافة", value: order.createdAt.formatted(date: .numeric, time: .shortened))
                        if let d = order.completedAt { InfoRow(title: "تاريخ الاكتمال", value: d.formatted(date: .numeric, time: .shortened)) }
                    }
                    DetailSection(title: "ملاحظات") {
                        Text(order.notes.isEmpty ? "لا توجد ملاحظات" : order.notes)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                            .foregroundStyle(.white.opacity(0.8))
                    }
                }
                .padding(16)
            }
        }
        .background(SwissTheme.background.ignoresSafeArea())
    }
}

struct DetailSection<Content: View>: View {
    let title: String
    @ViewBuilder let content: () -> Content
    var body: some View {
        VStack(alignment: .trailing, spacing: 12) {
            Text(title).font(.headline.bold()).foregroundStyle(.white)
            content()
        }
        .frame(maxWidth: .infinity, alignment: .trailing)
        .padding(16)
        .background(SwissTheme.card)
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }
}
