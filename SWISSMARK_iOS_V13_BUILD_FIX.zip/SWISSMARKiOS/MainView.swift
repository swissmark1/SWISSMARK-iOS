import SwiftUI

struct MainView: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                NavigationStack {
                    Group {
                        switch store.selectedTab {
                        case "الأوردرات":
                            OrdersView()
                        case "الإحصائيات":
                            StatisticsView()
                        default:
                            HomeView()
                        }
                    }
                    .toolbar(.hidden, for: .navigationBar)
                }
                .environment(\.layoutDirection, .rightToLeft)

                if store.drawerOpen {
                    Color.black
                        .opacity(0.55)
                        .ignoresSafeArea()
                        .contentShape(Rectangle())
                        .onTapGesture {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                store.drawerOpen = false
                            }
                        }

                    DrawerView()
                        .frame(width: min(geometry.size.width * 0.84, 360))
                        .transition(.move(edge: .leading))
                        .zIndex(5)
                }
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
        .background(SwissTheme.background.ignoresSafeArea())
    }
}

struct HeaderView: View {
    @EnvironmentObject var store: AppStore
    let title: String

    var body: some View {
        HStack(spacing: 12) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    store.drawerOpen = true
                }
            } label: {
                Image(systemName: "line.3.horizontal")
                    .font(.title3.weight(.bold))
                    .foregroundStyle(.white)
                    .frame(width: 42, height: 42)
                    .background(SwissTheme.card)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 2) {
                Text(title)
                    .font(.title3.bold())
                    .foregroundStyle(.white)

                Text("SWISSMARK")
                    .font(.caption.bold())
                    .foregroundStyle(SwissTheme.blue)
            }
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
    }
}

struct HomeView: View {
    @EnvironmentObject var store: AppStore

    private let columns = [
        GridItem(.flexible(), spacing: 10),
        GridItem(.flexible(), spacing: 10),
        GridItem(.flexible(), spacing: 10)
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                HeaderView(title: "الرئيسية")

                VStack(alignment: .trailing, spacing: 6) {
                    Text("SWISSMARK")
                        .font(.system(size: 32, weight: .black))
                        .foregroundStyle(.white)

                    Text("MAINTENANCE")
                        .font(.headline.bold())
                        .foregroundStyle(SwissTheme.blue)

                    Text("نظام إدارة الصيانة")
                        .foregroundStyle(.white.opacity(0.7))

                    Text("مرحباً بك في نظام الصيانة")
                        .foregroundStyle(.white.opacity(0.65))
                }
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(20)
                .background(
                    LinearGradient(
                        colors: [SwissTheme.card, SwissTheme.background],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .clipShape(RoundedRectangle(cornerRadius: 24))

                Text("إحصائيات الأوردرات")
                    .font(.title3.bold())
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, alignment: .trailing)

                LazyVGrid(columns: columns, spacing: 10) {
                    MetricCard(
                        title: "جميع الأوردرات",
                        value: "\(store.orders.count)",
                        color: SwissTheme.blue,
                        icon: "doc.text"
                    )

                    MetricCard(
                        title: "مكتملة",
                        value: "\(store.completed)",
                        color: SwissTheme.green,
                        icon: "checkmark.circle"
                    )

                    MetricCard(
                        title: "قيد الانتظار",
                        value: "\(store.waiting)",
                        color: SwissTheme.orange,
                        icon: "clock"
                    )

                    MetricCard(
                        title: "المستعجلة",
                        value: "\(store.urgent)",
                        color: SwissTheme.red,
                        icon: "exclamationmark.triangle"
                    )

                    MetricCard(
                        title: "لا يرد",
                        value: "\(store.noAnswer)",
                        color: SwissTheme.purple,
                        icon: "phone.down"
                    )

                    MetricCard(
                        title: "مؤجلة",
                        value: "\(store.postponed)",
                        color: SwissTheme.cyan,
                        icon: "calendar"
                    )
                }

                Text("الإجراءات السريعة")
                    .font(.title3.bold())
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, alignment: .trailing)

                NavigationLink {
                    AddOrderView()
                } label: {
                    ActionButton(
                        title: "إضافة أوردر جديد",
                        icon: "plus",
                        color: SwissTheme.blue
                    )
                }

                Button {
                    store.selectedTab = "الأوردرات"
                } label: {
                    ActionButton(
                        title: "عرض الأوردرات",
                        icon: "list.bullet",
                        color: SwissTheme.card
                    )
                }

                Button {
                    store.selectedTab = "الإحصائيات"
                } label: {
                    ActionButton(
                        title: "الإحصائيات",
                        icon: "chart.bar",
                        color: SwissTheme.card
                    )
                }

                NavigationLink {
                    OrdersView(filterUrgent: true)
                } label: {
                    ActionButton(
                        title: "المستعجلة",
                        icon: "exclamationmark.triangle.fill",
                        color: SwissTheme.red
                    )
                }

                Spacer(minLength: 25)

                BottomNav()
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
        }
        .background(SwissTheme.background.ignoresSafeArea())
        .environment(\.layoutDirection, .rightToLeft)
    }
}

struct MetricCard: View {
    let title: String
    let value: String
    let color: Color
    let icon: String

    var body: some View {
        VStack(alignment: .trailing, spacing: 7) {
            Image(systemName: icon)
                .foregroundStyle(.white.opacity(0.9))

            Text(value)
                .font(.system(size: 27, weight: .black))
                .foregroundStyle(.white)

            Text(title)
                .font(.caption.bold())
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity, minHeight: 105, alignment: .trailing)
        .padding(12)
        .background(color.opacity(0.95))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

struct ActionButton: View {
    let title: String
    let icon: String
    let color: Color

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.headline)

            Text(title)
                .fontWeight(.bold)

            Spacer()
        }
        .foregroundStyle(.white)
        .padding(17)
        .background(color)
        .clipShape(RoundedRectangle(cornerRadius: 17))
    }
}

struct BottomNav: View {
    @EnvironmentObject var store: AppStore

    var body: some View {
        HStack(spacing: 0) {
            NavItem(
                title: "حسابي",
                icon: "person",
                selected: false
            ) {}

            NavItem(
                title: "الإعدادات",
                icon: "gearshape",
                selected: false
            ) {
                store.drawerOpen = true
            }

            NavItem(
                title: "الرئيسية",
                icon: "house.fill",
                selected: store.selectedTab == "الرئيسية"
            ) {
                store.selectedTab = "الرئيسية"
            }

            NavItem(
                title: "الإحصائيات",
                icon: "chart.bar",
                selected: store.selectedTab == "الإحصائيات"
            ) {
                store.selectedTab = "الإحصائيات"
            }

            NavItem(
                title: "الأوردرات",
                icon: "doc.text",
                selected: store.selectedTab == "الأوردرات"
            ) {
                store.selectedTab = "الأوردرات"
            }
        }
        .padding(8)
        .background(SwissTheme.card)
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }
}

struct NavItem: View {
    let title: String
    let icon: String
    let selected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)

                Text(title)
                    .font(.system(size: 10, weight: .bold))
            }
            .foregroundStyle(
                selected
                ? SwissTheme.blue
                : .white.opacity(0.7)
            )
            .frame(maxWidth: .infinity)
        }
    }
}
