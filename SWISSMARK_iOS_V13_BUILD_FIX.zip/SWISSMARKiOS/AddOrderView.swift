
import SwiftUI

struct AddOrderView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var customer = ""
    @State private var phone = ""
    @State private var secondPhone = ""
    @State private var region = ""
    @State private var device = ""
    @State private var fault = ""
    @State private var technician = ""
    @State private var notes = ""
    @State private var urgent = false

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                HeaderView(title: "إضافة أوردر جديد")
                FormField("اسم الزبون", $customer)
                FormField("رقم الهاتف", $phone, keyboard: .phonePad)
                FormField("رقم هاتف ثاني (اختياري)", $secondPhone, keyboard: .phonePad)
                FormField("المنطقة", $region)
                FormField("الجهاز", $device)
                FormField("نوع العطل", $fault)
                FormField("الفني", $technician)
                FormField("ملاحظات", $notes)

                Toggle(isOn: $urgent) {
                    Text("أوردر مستعجل").foregroundStyle(.white).fontWeight(.bold)
                }
                .tint(SwissTheme.red)
                .padding()
                .background(SwissTheme.card)
                .clipShape(RoundedRectangle(cornerRadius: 16))

                Button {
                    let next = (store.orders.map(\.number).max() ?? 1000) + 1
                    store.add(Order(id: UUID().uuidString, number: next, customer: customer, phone: phone, secondPhone: secondPhone, region: region, device: device, fault: fault, status: .waiting, createdAt: Date(), completedAt: nil, technician: technician, fee: 0, urgent: urgent, location: "", notes: notes))
                    dismiss()
                } label: {
                    Text("حفظ الأوردر").fontWeight(.bold).frame(maxWidth: .infinity).padding()
                }
                .background(SwissTheme.blue).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 16))
            }
            .padding(16)
        }
        .background(SwissTheme.background.ignoresSafeArea())
    }
}

struct FormField: View {
    let title: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default
    var body: some View {
        VStack(alignment: .trailing, spacing: 6) {
            Text(title).font(.caption.bold()).foregroundStyle(.white.opacity(0.7))
            TextField("", text: $text)
                .keyboardType(keyboard)
                .multilineTextAlignment(.trailing)
                .padding(14)
                .background(SwissTheme.card)
                .foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 14))
        }
    }
}
