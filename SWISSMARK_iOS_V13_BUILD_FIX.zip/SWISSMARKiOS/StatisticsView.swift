
import SwiftUI

struct StatisticsView: View {
    @EnvironmentObject var store: AppStore
    var body: some View {
        ScrollView {
            VStack(spacing: 15) {
                HeaderView(title: "الإحصائيات")
                Text("إحصائيات الأوردرات")
                    .font(.title2.bold()).foregroundStyle(.white)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                StatisticRow(title: "جميع الأوردرات", value: store.orders.count, color: SwissTheme.blue)
                StatisticRow(title: "مكتملة", value: store.completed, color: SwissTheme.green)
                StatisticRow(title: "قيد الانتظار", value: store.waiting, color: SwissTheme.orange)
                StatisticRow(title: "مستعجلة", value: store.urgent, color: SwissTheme.red)
                StatisticRow(title: "لا يرد", value: store.noAnswer, color: SwissTheme.purple)
                StatisticRow(title: "مؤجلة", value: store.postponed, color: SwissTheme.cyan)

                Text("حسب الحالة")
                    .font(.title3.bold()).foregroundStyle(.white)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                ForEach(OrderStatus.allCases) { status in
                    let count = store.orders.filter { $0.status == status }.count
                    if count > 0 {
                        HStack {
                            Text("\(count)").font(.headline.bold()).foregroundStyle(.white)
                            Spacer()
                            Text(status.rawValue).foregroundStyle(.white)
                        }
                        .padding()
                        .background(SwissTheme.card)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                    }
                }
            }
            .padding(16)
        }
        .background(SwissTheme.background.ignoresSafeArea())
    }
}

struct StatisticRow: View {
    let title: String; let value: Int; let color: Color
    var body: some View {
        HStack {
            Text("\(value)").font(.system(size: 30, weight: .black)).foregroundStyle(.white)
            Spacer()
            Text(title).font(.headline.bold()).foregroundStyle(.white)
        }
        .padding(18)
        .background(color)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}
