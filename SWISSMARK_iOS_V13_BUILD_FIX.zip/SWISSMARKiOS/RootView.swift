
import SwiftUI

struct RootView: View {
    @EnvironmentObject var store: AppStore
    var body: some View {
        ZStack {
            if store.loggedIn {
                MainView()
            } else {
                LoginView()
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }
}

struct LoginView: View {
    @EnvironmentObject var store: AppStore
    @State private var username = ""
    @State private var password = ""
    var body: some View {
        ZStack {
            SwissTheme.background.ignoresSafeArea()
            VStack(spacing: 22) {
                Spacer()
                VStack(spacing: 8) {
                    Text("SWISSMARK")
                        .font(.system(size: 38, weight: .black))
                        .foregroundStyle(.white)
                    Text("MAINTENANCE")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(SwissTheme.blue)
                    Text("نظام إدارة الصيانة")
                        .foregroundStyle(.white.opacity(0.7))
                }
                .padding(.bottom, 25)
                VStack(spacing: 14) {
                    TextField("اسم المستخدم", text: $username)
                        .textInputAutocapitalization(.never)
                        .padding()
                        .background(SwissTheme.card)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    SecureField("كلمة المرور", text: $password)
                        .padding()
                        .background(SwissTheme.card)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    Button {
                        store.userName = username.isEmpty ? "SWISSMARK" : username
                        store.loggedIn = true
                    } label: {
                        Text("تسجيل الدخول")
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity)
                            .padding()
                    }
                    .background(SwissTheme.blue)
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                Spacer()
                Text("SWISSMARK • Always at Your Service")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.45))
            }
            .padding(24)
        }
    }
}
