
import SwiftUI

enum SwissTheme {
    static let background = Color(red: 6/255, green: 20/255, blue: 38/255)
    static let card = Color(red: 23/255, green: 47/255, blue: 77/255)
    static let blue = Color(red: 37/255, green: 99/255, blue: 235/255)
    static let green = Color(red: 8/255, green: 185/255, blue: 104/255)
    static let orange = Color(red: 1, green: 168/255, blue: 0)
    static let red = Color(red: 245/255, green: 34/255, blue: 62/255)
    static let purple = Color(red: 113/255, green: 56/255, blue: 232/255)
    static let cyan = Color(red: 18/255, green: 169/255, blue: 200/255)
    static let text = Color(red: 234/255, green: 240/255, blue: 1)
}
