
import Foundation

enum OrderStatus: String, CaseIterable, Identifiable {
    case waiting = "قيد الانتظار"
    case noAnswer = "لا يرد"
    case postponed = "مؤجل"
    case visited = "تمت الزيارة"
    case testing = "تحت التجربة"
    case technical = "خلل فني"
    case completed = "مكتمل"
    case workshop = "تم في الورشة"
    case replaced = "تم الاستبدال"
    var id: String { rawValue }
}

enum UserRole: String {
    case manager = "مدير"
    case assistant = "مساعد مدير"
    case technician = "فني"
    case followUp = "متابعة"
}

struct Order: Identifiable, Hashable {
    let id: String
    var number: Int
    var customer: String
    var phone: String
    var secondPhone: String
    var region: String
    var device: String
    var fault: String
    var status: OrderStatus
    var createdAt: Date
    var completedAt: Date?
    var technician: String
    var fee: Double
    var urgent: Bool
    var location: String
    var notes: String
}

@MainActor
final class AppStore: ObservableObject {
    @Published var loggedIn = false
    @Published var userName = "SWISSMARK"
    @Published var role: UserRole = .manager
    @Published var selectedTab = "الرئيسية"
    @Published var drawerOpen = false
    @Published var orders: [Order] = [
        Order(id: "1", number: 1001, customer: "أحمد محمد", phone: "07700000000", secondPhone: "", region: "المنصور", device: "غسالة", fault: "لا تعمل", status: .completed, createdAt: Date().addingTimeInterval(-86400*2), completedAt: Date().addingTimeInterval(-86400), technician: "فني 1", fee: 25000, urgent: false, location: "", notes: ""),
        Order(id: "2", number: 1002, customer: "محمد علي", phone: "07800000000", secondPhone: "", region: "الكرادة", device: "ثلاجة", fault: "ضعف تبريد", status: .waiting, createdAt: Date().addingTimeInterval(-86400), completedAt: nil, technician: "فني 2", fee: 0, urgent: true, location: "", notes: ""),
        Order(id: "3", number: 1003, customer: "سارة كريم", phone: "07900000000", secondPhone: "", region: "زيونة", device: "مكيف", fault: "تسريب ماء", status: .postponed, createdAt: Date(), completedAt: nil, technician: "فني 1", fee: 0, urgent: false, location: "", notes: "")
    ]
    func add(_ order: Order) { orders.insert(order, at: 0) }
    var completed: Int { orders.filter { [.completed,.workshop,.replaced].contains($0.status) }.count }
    var waiting: Int { orders.filter { $0.status == .waiting }.count }
    var urgent: Int { orders.filter(\.urgent).count }
    var noAnswer: Int { orders.filter { $0.status == .noAnswer }.count }
    var postponed: Int { orders.filter { $0.status == .postponed }.count }
}
