
import SwiftUI

struct OrdersView: View {
    @EnvironmentObject var store: AppStore
    var filterUrgent: Bool = false
    @State private var search = ""
    @State private var selectedStatus: OrderStatus?
    var filtered: [Order] {
        store.orders.filter {
            (!filterUrgent || $0.urgent) &&
            (selectedStatus == nil || $0.status == selectedStatus) &&
            (search.isEmpty || $0.customer.localizedCaseInsensitiveContains(search) || $0.phone.contains(search))
        }
    }
    var body: some View {
        VStack(spacing: 0) {
            HeaderView(title: filterUrgent ? "الأوردرات المستعجلة" : "الأوردرات")
            HStack {
                Image(systemName: "magnifyingglass")
                TextField("بحث باسم الزبون أو الهاتف", text: $search)
            }
            .padding(13)
            .background(SwissTheme.card)
            .clipShape(RoundedRectangle(cornerRadius: 15))
            .padding(.horizontal, 16)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    StatusChip(title: "الكل", active: selectedStatus == nil) { selectedStatus = nil }
                    ForEach(OrderStatus.allCases) { status in
                        StatusChip(title: status.rawValue, active: selectedStatus == status) { selectedStatus = status }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
            }

            ScrollView {
                LazyVStack(spacing: 11) {
                    ForEach(filtered) { order in
                        NavigationLink { OrderDetailView(orderID: order.id) } label: {
                            OrderCardView(order: order)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(16)
            }
        }
        .background(SwissTheme.background.ignoresSafeArea())
    }
}

struct StatusChip: View {
    let title: String; let active: Bool; let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.caption.bold())
                .foregroundStyle(.white)
                .padding(.horizontal, 12).padding(.vertical, 8)
                .background(active ? SwissTheme.blue : SwissTheme.card)
                .clipShape(Capsule())
        }
    }
}

struct OrderCardView: View {
    let order: Order
    var body: some View {
        VStack(alignment: .trailing, spacing: 10) {
            HStack {
                if order.urgent {
                    Text("مستعجل")
                        .font(.caption.bold())
                        .foregroundStyle(.white)
                        .padding(.horizontal, 9).padding(.vertical, 5)
                        .background(SwissTheme.red)
                        .clipShape(Capsule())
                }
                Spacer()
                Text("#\(order.number)")
                    .font(.headline.bold()).foregroundStyle(.white)
            }
            Divider().overlay(.white.opacity(0.12))
            InfoRow(title: "الزبون", value: order.customer)
            InfoRow(title: "الهاتف", value: order.phone)
            InfoRow(title: "الجهاز", value: order.device)
            InfoRow(title: "العطل", value: order.fault)
            InfoRow(title: "المنطقة", value: order.region)
            HStack {
                Text(order.status.rawValue)
                    .font(.caption.bold())
                    .foregroundStyle(statusColor(order.status))
                Spacer()
                Text(order.createdAt.formatted(date: .numeric, time: .shortened))
                    .font(.caption).foregroundStyle(.white.opacity(0.55))
            }
        }
        .padding(16)
        .background(SwissTheme.card)
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }
}

struct InfoRow: View {
    let title: String; let value: String
    var body: some View {
        HStack {
            Text(value).foregroundStyle(.white).fontWeight(.medium)
            Spacer()
            Text(title).foregroundStyle(.white.opacity(0.55)).font(.caption)
        }
    }
}

func statusColor(_ status: OrderStatus) -> Color {
    switch status {
    case .completed, .workshop, .replaced: return SwissTheme.green
    case .waiting: return SwissTheme.orange
    case .noAnswer: return SwissTheme.purple
    case .postponed: return SwissTheme.cyan
    case .technical: return SwissTheme.red
    default: return SwissTheme.blue
    }
}
