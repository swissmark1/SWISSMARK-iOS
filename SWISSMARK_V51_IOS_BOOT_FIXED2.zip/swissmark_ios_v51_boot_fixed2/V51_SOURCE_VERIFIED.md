# SWISSMARK V51 source basis

This project is being ported from the verified `SWISSMARK_MainActivity_V51_Sheets_SERIAL_FIXED.kt` source:
- 8,571 Kotlin source lines
- Firebase Auth / Firestore / Messaging
- Google Sheets archive
- Cloudflare Worker + Backblaze video storage
- Waze/location integration
- roles, order statuses, audit/status history, media, reports, expenses, blacklist, trash and chat screens

This repository version specifically hardens the iOS boot path so missing Firebase iOS configuration cannot produce an unexplained blank screen.
