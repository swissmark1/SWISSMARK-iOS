# SWISSMARK V51 iOS Firebase setup

The app now fails visibly instead of showing a blank screen when the iOS Firebase configuration is missing.

Add the iOS Firebase file named `GoogleService-Info.plist` to `ios/Runner/` and include it in the Runner target. The bundle identifier must match the iOS app registered in the same Firebase project.

The real Android V51 source uses Firebase Authentication, Firestore and FCM. This iOS port keeps those services as the target architecture.
