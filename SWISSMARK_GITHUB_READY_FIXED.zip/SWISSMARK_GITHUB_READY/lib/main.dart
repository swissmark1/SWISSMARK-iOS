import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';

const statuses = [
  'قيد الانتظار','مكتمل','تم السحب','لا يرد','مؤجل','تم في الورشة',
  'تم الاستبدال','تمت الزيارة','تحت التجربة','تم هاتفياً','رفض الصيانة','رفض دفع الأجور'
];

enum Role { superAdmin, manager, assistantManager, technician, followUp, unknown }

Role roleFrom(String? value) {
  switch ((value ?? '').trim().toLowerCase()) {
    case 'super_admin': case 'superadmin': case 'super admin': return Role.superAdmin;
    case 'manager': case 'مدير': return Role.manager;
    case 'assistant_manager': case 'assistant manager': case 'مساعد المدير': return Role.assistantManager;
    case 'technician': case 'فني': case 'فني صيانة': return Role.technician;
    case 'follow_up': case 'follow up': case 'المتابعة': case 'متابعة': return Role.followUp;
    default: return Role.unknown;
  }
}

extension RoleX on Role {
  String get label => switch (this) {
    Role.superAdmin => 'الإدارة', Role.manager => 'المدير',
    Role.assistantManager => 'مساعد المدير', Role.technician => 'الفني',
    Role.followUp => 'المتابعة', Role.unknown => 'غير معروف'
  };
  bool get canManageUsers => this == Role.superAdmin || this == Role.manager;
  bool get canDeleteOrder => this == Role.superAdmin || this == Role.manager;
  bool get canAddOrder => this != Role.technician && this != Role.unknown;
  bool get canMarkUrgent => this != Role.technician && this != Role.unknown;
  bool get canAddPhotos => this != Role.followUp && this != Role.unknown;
  bool get canViewExpenses => this == Role.superAdmin || this == Role.manager || this == Role.followUp || this == Role.technician;
  bool get canManageMedia => this == Role.superAdmin || this == Role.manager || this == Role.assistantManager || this == Role.technician;
}

class OrderModel {
  String id, customerName, agent, phone, secondPhone, region, device, faultType, status, location, notes;
  int orderNumber;
  DateTime dateAdded;
  DateTime? completionDate;
  double maintenanceFee;
  bool urgent;
  List<String> photos, videos;
  OrderModel({
    this.id='', this.orderNumber=0, this.customerName='', this.agent='', this.phone='',
    this.secondPhone='', this.region='', this.device='', this.faultType='',
    this.status='قيد الانتظار', DateTime? dateAdded, this.completionDate,
    this.maintenanceFee=0, this.urgent=false, this.photos=const [], this.videos=const [],
    this.location='', this.notes=''
  }) : dateAdded = dateAdded ?? DateTime.now();

  factory OrderModel.fromDoc(DocumentSnapshot<Map<String,dynamic>> d) {
    final x=d.data() ?? {};
    return OrderModel(
      id:d.id, orderNumber:(x['orderNumber'] ?? 0) is int ? x['orderNumber'] : int.tryParse('${x['orderNumber']}') ?? 0,
      customerName:'${x['customerName'] ?? ''}', agent:'${x['agent'] ?? ''}', phone:'${x['phone'] ?? ''}',
      secondPhone:'${x['secondPhone'] ?? ''}', region:'${x['region'] ?? ''}', device:'${x['device'] ?? ''}',
      faultType:'${x['faultType'] ?? ''}', status:'${x['status'] ?? 'قيد الانتظار'}',
      dateAdded:DateTime.fromMillisecondsSinceEpoch((x['dateAdded'] ?? 0) as int),
      completionDate:(x['completionDate'] as int?) == null ? null : DateTime.fromMillisecondsSinceEpoch(x['completionDate']),
      maintenanceFee:((x['maintenanceFee'] ?? 0) as num).toDouble(), urgent:x['urgent'] == true,
      photos:List<String>.from(x['photos'] ?? const []), videos:List<String>.from(x['videos'] ?? const []),
      location:'${x['customerLocation'] ?? ''}', notes:'${x['notes'] ?? ''}'
    );
  }
  Map<String,dynamic> toMap()=> {
    'orderNumber':orderNumber,'customerName':customerName,'agent':agent,'phone':phone,'secondPhone':secondPhone,
    'region':region,'device':device,'faultType':faultType,'status':status,'dateAdded':dateAdded.millisecondsSinceEpoch,
    'completionDate':completionDate?.millisecondsSinceEpoch,'maintenanceFee':maintenanceFee,'urgent':urgent,
    'photos':photos,'videos':videos,'customerLocation':location,'notes':notes
  };
}

class AppRepo {
  final db=FirebaseFirestore.instance;
  final auth=FirebaseAuth.instance;
  Stream<List<OrderModel>> orders() => db.collection('orders').orderBy('dateAdded', descending:true)
    .snapshots().map((s)=>s.docs.map(OrderModel.fromDoc).toList());
  Future<void> addOrder(OrderModel o) async {
    final q=await db.collection('orders').orderBy('orderNumber', descending:true).limit(1).get();
    final next=q.docs.isEmpty?1:((q.docs.first.data()['orderNumber'] ?? 0) as num).toInt()+1;
    o.orderNumber=next; final ref=await db.collection('orders').add(o.toMap());
    await audit(ref.id,'إضافة أوردر','تم إنشاء الأوردر رقم $next');
  }
  Future<void> updateOrder(OrderModel o, {String? fromStatus}) async {
    await db.collection('orders').doc(o.id).update(o.toMap());
    if(fromStatus!=null && fromStatus!=o.status) await db.collection('orders').doc(o.id).collection('statusHistory').add({
      'fromStatus':fromStatus,'toStatus':o.status,'changedAt':DateTime.now().millisecondsSinceEpoch,
      'changedBy':auth.currentUser?.email ?? 'مستخدم'
    });
    await audit(o.id,'تعديل الأوردر','تم تحديث بيانات الأوردر');
  }
  Future<void> deleteOrder(OrderModel o) async {
    await db.collection('deletedOrders').doc(o.id).set(o.toMap()..addAll({'deletedAt':DateTime.now().millisecondsSinceEpoch,'originalId':o.id}));
    await db.collection('orders').doc(o.id).delete();
  }
  Future<void> audit(String id,String action,String details) => db.collection('orders').doc(id).collection('changeLog').add({
    'action':action,'details':details,'changedAt':DateTime.now().millisecondsSinceEpoch,
    'changedBy':auth.currentUser?.email ?? 'مستخدم'
  });
}

final repo=AppRepo();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try { await Firebase.initializeApp(); } catch (_) {}
  runApp(const SwissMarkApp());
}

class SwissMarkApp extends StatelessWidget {
  const SwissMarkApp({super.key});
  @override Widget build(BuildContext c)=>MaterialApp(
    debugShowCheckedModeBanner:false, title:'SWISS MARK',
    theme:ThemeData.dark(useMaterial3:true).copyWith(
      scaffoldBackgroundColor:const Color(0xFF06182B), colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF1687FF), brightness:Brightness.dark),
      inputDecorationTheme:const InputDecorationTheme(filled:true, fillColor:Color(0xFF0D2743), border:OutlineInputBorder()),
    ), home:const AuthGate()
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override Widget build(BuildContext c)=>StreamBuilder<User?>(stream:FirebaseAuth.instance.authStateChanges(),
    builder:(c,s)=>s.data==null?const LoginPage():const MainPage());
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage>{
  final email=TextEditingController(), pass=TextEditingController(); bool busy=false;
  Future<void> login() async { setState(()=>busy=true); try { await FirebaseAuth.instance.signInWithEmailAndPassword(email:email.text.trim(),password:pass.text); } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تسجيل الدخول: $e'))); } setState(()=>busy=false); }
  @override Widget build(BuildContext c)=>Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(children:[
    const Text('SWISS MARK',style:TextStyle(fontSize:34,fontWeight:FontWeight.bold)),
    const SizedBox(height:30),TextField(controller:email,decoration:const InputDecoration(labelText:'اسم المستخدم / البريد')),
    const SizedBox(height:12),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'كلمة المرور')),
    const SizedBox(height:20),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:login,child:Text(busy?'جاري الدخول...':'دخول')))
  ]))));
}

class MainPage extends StatefulWidget { const MainPage({super.key}); State<MainPage> createState()=>_MainPageState(); }
class _MainPageState extends State<MainPage>{
  int tab=0; String search=''; String status='الكل';
  final searchCtl=TextEditingController();
  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('SWISS MARK'),actions:[IconButton(icon:const Icon(Icons.logout),onPressed:()=>FirebaseAuth.instance.signOut())]),
    drawer:Drawer(child:ListView(children:[
      const DrawerHeader(child:Center(child:Text('SWISS MARK',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)))),
      _nav(Icons.home,'الرئيسية',0),_nav(Icons.receipt_long,'الأوردرات',1),_nav(Icons.add_box,'إضافة أوردر',2),
      _nav(Icons.bar_chart,'الإحصائيات',3),_nav(Icons.people,'الزبائن',4),_nav(Icons.block,'البلاك ليست',5),
      _nav(Icons.account_balance_wallet,'المشتريات والمصاريف',6),_nav(Icons.photo_library,'إدارة الوسائط',7),
      _nav(Icons.description,'التقارير',8),_nav(Icons.delete_sweep,'سلة المحذوفات',9),_nav(Icons.settings,'الإعدادات',10)
    ])),
    body:_body()
  );
  Widget _nav(IconData i,String t,int n)=>ListTile(leading:Icon(i),title:Text(t),onTap:(){Navigator.pop(context);setState(()=>tab=n);});
  Widget _body()=>switch(tab){
    0=>const HomePage(),1=>OrdersPage(searchCtl:searchCtl),2=>const AddOrderPage(),3=>const StatisticsPage(),
    4=>const CustomersPage(),5=>const BlacklistPage(),6=>const ExpensesPage(),7=>const MediaPage(),
    8=>const ReportsPage(),9=>const RecyclePage(),10=>const SettingsPage(),_=>const HomePage()
  };
}

class HomePage extends StatelessWidget{
 const HomePage({super.key});
 @override Widget build(BuildContext c)=>StreamBuilder<List<OrderModel>>(stream:repo.orders(),builder:(c,s){
  final o=s.data??[]; final completed=o.where((x)=>x.status=='مكتمل'||x.status=='تم في الورشة'||x.status=='تم الاستبدال').length;
  return ListView(padding:const EdgeInsets.all(16),children:[
   const Text('لوحة التحكم',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const SizedBox(height:18),
   Wrap(spacing:10,runSpacing:10,children:[_metric('كل الأوردرات',o.length,Icons.receipt_long),_metric('قيد الانتظار',o.where((x)=>x.status=='قيد الانتظار').length,Icons.hourglass_empty),_metric('مكتمل',completed,Icons.check_circle),_metric('مستعجل',o.where((x)=>x.urgent).length,Icons.priority_high)]),
   const SizedBox(height:22),const Text('آخر الأوردرات',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
   ...o.take(8).map((x)=>OrderTile(o:x))
  ];});
 Widget _metric(String t,int n,IconData i)=>SizedBox(width:160,height:110,child:Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(i),Text('$n',style:const TextStyle(fontSize:28,fontWeight:FontWeight.bold)),Text(t)]))));
}

class OrdersPage extends StatelessWidget{
 final TextEditingController searchCtl; const OrdersPage({super.key,required this.searchCtl});
 @override Widget build(BuildContext c)=>StreamBuilder<List<OrderModel>>(stream:repo.orders(),builder:(c,s){
  var data=s.data??[]; final q=searchCtl.text.trim();
  if(q.isNotEmpty) data=data.where((o)=>o.customerName.contains(q)||o.phone.contains(q)||'${o.orderNumber}'==q).toList();
  return Column(children:[Padding(padding:const EdgeInsets.all(12),child:TextField(controller:searchCtl,onChanged:(_)=> (c as Element).markNeedsBuild(),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'بحث بالاسم أو الهاتف أو رقم الأوردر'))),
    Expanded(child:ListView(children:data.map((o)=>OrderTile(o:o)).toList()))]);
 }
}
class OrderTile extends StatelessWidget{
 final OrderModel o; const OrderTile({super.key,required this.o});
 @override Widget build(BuildContext c)=>Card(child:ListTile(
  leading:CircleAvatar(child:Text('${o.orderNumber}')),title:Text(o.customerName.isEmpty?'بدون اسم':o.customerName),
  subtitle:Text('${o.device} • ${o.faultType}\\n${o.phone}\\n${DateFormat('yyyy-MM-dd HH:mm').format(o.dateAdded)}'),
  isThreeLine:true,trailing:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text(o.status),if(o.urgent)const Icon(Icons.priority_high)]),
  onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>OrderDetails(o:o)))
 ));
}

class OrderDetails extends StatefulWidget{final OrderModel o;const OrderDetails({super.key,required this.o});State<OrderDetails>createState()=>_OrderDetailsState();}
class _OrderDetailsState extends State<OrderDetails>{
 late OrderModel o; @override void initState(){super.initState();o=widget.o;}
 Future<void> saveStatus(String st)async{final old=o.status;setState(()=>o.status=st);if(statuses.contains(st)) {o.completionDate=(st=='مكتمل'||st=='تم في الورشة'||st=='تم الاستبدال'||st=='تم هاتفياً')?DateTime.now():o.completionDate;await repo.updateOrder(o,fromStatus:old);}}
 Future<void> location()async{if(!await Geolocator.isLocationServiceEnabled())return;var p=await Geolocator.requestPermission();if(p==LocationPermission.denied||p==LocationPermission.deniedForever)return;final x=await Geolocator.getCurrentPosition();setState(()=>o.location='${x.latitude.toStringAsFixed(6)}, ${x.longitude.toStringAsFixed(6)}');await repo.updateOrder(o);}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text('أوردر #${o.orderNumber}')),body:ListView(padding:const EdgeInsets.all(16),children:[
  _row('الزبون',o.customerName),_row('الهاتف',o.phone),_row('الوكيل',o.agent),_row('المنطقة',o.region),_row('الجهاز',o.device),_row('العطل',o.faultType),
  _row('تاريخ النزول',DateFormat('yyyy-MM-dd HH:mm').format(o.dateAdded)),_row('الموقع',o.location.isEmpty?'غير مضاف':o.location),
  if(o.notes.isNotEmpty)_row('الملاحظات',o.notes),
  const SizedBox(height:14),DropdownButtonFormField<String>(value:o.status,items:statuses.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v){if(v!=null)saveStatus(v);},decoration:const InputDecoration(labelText:'الحالة')),
  const SizedBox(height:12),TextFormField(initialValue:o.maintenanceFee==0?'':o.maintenanceFee.toString(),keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'أجور الصيانة'),onFieldSubmitted:(v)async{final n=double.tryParse(v);if(n!=null){o.maintenanceFee=n;await repo.updateOrder(o);}}),
  SwitchListTile(title:const Text('مستعجل'),value:o.urgent,onChanged:(v)async{setState(()=>o.urgent=v);await repo.updateOrder(o);}),
  Row(children:[Expanded(child:FilledButton.icon(onPressed:location,icon:const Icon(Icons.location_on),label:const Text('موقعي'))),const SizedBox(width:8),Expanded(child:OutlinedButton.icon(onPressed:o.location.isEmpty?null:()=>launchUrl(Uri.parse('https://waze.com/ul?ll=${o.location}&navigate=yes')),icon:const Icon(Icons.navigation),label:const Text('Waze')))]),
  const SizedBox(height:12),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:()=>Share.share(o.phone),icon:const Icon(Icons.share),label:const Text('مشاركة الهاتف'))),const SizedBox(width:8),Expanded(child:OutlinedButton.icon(onPressed:()=>launchUrl(Uri.parse('tel:${o.phone}')),icon:const Icon(Icons.call),label:const Text('اتصال')))]),
  const SizedBox(height:18),FilledButton.icon(onPressed:()=>showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('حذف الأوردر؟'),content:const Text('سيُنقل إلى سلة المحذوفات.'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()async{await repo.deleteOrder(o);if(c.mounted){Navigator.pop(c);Navigator.pop(c);}},child:const Text('حذف'))])),icon:const Icon(Icons.delete),label:const Text('حذف الأوردر'))
 ]));
 Widget _row(String a,String b)=>Card(child:ListTile(title:Text(a),subtitle:Text(b.isEmpty?'—':b)));
}

class AddOrderPage extends StatefulWidget{const AddOrderPage({super.key});State<AddOrderPage>createState()=>_AddOrderPageState();}
class _AddOrderPageState extends State<AddOrderPage>{
 final f=GlobalKey<FormState>(); final c=TextEditingController(),a=TextEditingController(),p=TextEditingController(),sp=TextEditingController(),r=TextEditingController(),d=TextEditingController(),fault=TextEditingController(),notes=TextEditingController();bool urgent=false,busy=false;
 Future<void> save()async{if(!f.currentState!.validate())return;setState(()=>busy=true);await repo.addOrder(OrderModel(customerName:c.text,agent:a.text,phone:p.text,secondPhone:sp.text,region:r.text,device:d.text,faultType:fault.text,notes:notes.text,urgent:urgent));if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تمت إضافة الأوردر')));Navigator.pop(context);}setState(()=>busy=false);}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('إضافة أوردر')),body:Form(key:f,child:ListView(padding:const EdgeInsets.all(16),children:[
  _in(this.c,'اسم الزبون',true),_in(a,'الوكيل'),_in(p,'رقم الهاتف',true),_in(sp,'رقم ثانٍ'),_in(r,'المنطقة'),_in(d,'الجهاز',true),_in(fault,'نوع العطل',true),_in(notes,'الملاحظات'),SwitchListTile(title:const Text('مستعجل'),value:urgent,onChanged:(v)=>setState(()=>urgent=v)),
  const SizedBox(height:12),FilledButton(onPressed:busy?null:save,child:Text(busy?'جاري الحفظ...':'حفظ الأوردر'))
 ]));}
 Widget _in(TextEditingController x,String label,[bool req=false])=>Padding(padding:const EdgeInsets.only(bottom:10),child:TextFormField(controller:x,decoration:InputDecoration(labelText:label),validator:req?(v)=>v==null||v.trim().isEmpty?'مطلوب':'' :null));
}

class StatisticsPage extends StatelessWidget{const StatisticsPage({super.key});@override Widget build(BuildContext c)=>StreamBuilder<List<OrderModel>>(stream:repo.orders(),builder:(c,s){final o=s.data??[];final map=<String,int>{};for(final x in o){map[x.status]=(map[x.status]??0)+1;}return ListView(padding:const EdgeInsets.all(16),children:[const Text('الإحصائيات',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),...map.entries.map((e)=>ListTile(title:Text(e.key),trailing:Text('${e.value}',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))))]);}}

class CustomersPage extends StatelessWidget{const CustomersPage({super.key});@override Widget build(BuildContext c)=>StreamBuilder<List<OrderModel>>(stream:repo.orders(),builder:(c,s){final o=s.data??[];final m=<String,List<OrderModel>>{};for(final x in o){if(x.phone.isNotEmpty)m.putIfAbsent(x.phone,()=>[]).add(x);}return ListView(padding:const EdgeInsets.all(16),children:[const Text('سجل الزبائن',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),...m.entries.map((e)=>Card(child:ListTile(title:Text(e.value.first.customerName),subtitle:Text('${e.key} • ${e.value.length} أوردر'),onTap:()=>showDialog(context:c,builder:(_)=>AlertDialog(title:Text(e.value.first.customerName),content:Text(e.value.map((x)=>'#${x.orderNumber} ${x.device} — ${x.status}').join('\\n'))))))]);}}

class BlacklistPage extends StatelessWidget{const BlacklistPage({super.key});@override Widget build(BuildContext c)=>StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirebaseFirestore.instance.collection('blacklist').snapshots(),builder:(c,s)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('البلاك ليست',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),...(s.data?.docs??[]).map((d)=>Card(child:ListTile(title:Text(d.id),subtitle:Text('${d.data()['reason']??''}'))))]));}

class ExpensesPage extends StatelessWidget {
  const ExpensesPage({super.key});

  @override
  Widget build(BuildContext c) => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
    stream: FirebaseFirestore.instance
        .collection('expenses')
        .orderBy('date', descending: true)
        .snapshots(),
    builder: (c, s) {
      double total = 0;
      for (final d in s.data?.docs ?? []) {
        final value = d.data()['amount'];
        total += ((value as num?) ?? 0).toDouble();
      }
      return ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('المشتريات والمصاريف', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          Text('المجموع: $total', style: const TextStyle(fontSize: 22)),
          ...(s.data?.docs ?? []).map((d) => ListTile(
            title: Text('${d.data()['title'] ?? ''}'),
            trailing: Text('${d.data()['amount'] ?? 0}'),
          )),
        ],
      );
    },
  );
}

class MediaPage extends StatelessWidget{const MediaPage({super.key});@override Widget build(BuildContext c)=>const Center(child:Text('إدارة الوسائط\\nالصور والفيديوهات المرتبطة بالأوردرات'));}
class ReportsPage extends StatelessWidget{const ReportsPage({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('التقارير',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const ListTile(title:Text('تقرير 1–15'),subtitle:Text('جاهز للربط بتوليد PDF')),const ListTile(title:Text('تقرير 16–نهاية الشهر'),subtitle:Text('جاهز للربط بتوليد PDF'))]);}
class RecyclePage extends StatelessWidget{const RecyclePage({super.key});@override Widget build(BuildContext c)=>StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:FirebaseFirestore.instance.collection('deletedOrders').orderBy('deletedAt',descending:true).snapshots(),builder:(c,s)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('سلة المحذوفات',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),...(s.data?.docs??[]).map((d)=>ListTile(title:Text('#${d.data()['orderNumber']??''} ${d.data()['customerName']??''}'),subtitle:Text('محذوف')))]));}
class SettingsPage extends StatelessWidget{const SettingsPage({super.key});@override Widget build(BuildContext c)=>ListView(children:[const ListTile(title:Text('SWISS MARK'),subtitle:Text('إعدادات التطبيق والصلاحيات')),ListTile(title:Text('تغيير كلمة المرور'),onTap:()=>showDialog(context:c,builder:(_)=>const AlertDialog(title:Text('تغيير كلمة المرور'),content:Text('سيتم استخدام Firebase Authentication.'))))]);}
