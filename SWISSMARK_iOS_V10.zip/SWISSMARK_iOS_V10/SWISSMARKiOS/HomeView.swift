import SwiftUI

struct HomeView: View {
    @EnvironmentObject var store: AppStore
    @Binding var selected: AppSection
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                header
                LazyVGrid(columns: [GridItem(.flexible()),GridItem(.flexible())], spacing: 12) {
                    Stat(title:"كل الأوردرات", value: store.orders.count, color:.swissBlue, icon:"list.clipboard.fill") { selected = .orders }
                    Stat(title:"قيد الانتظار", value: count("قيد الانتظار"), color:.swissOrange, icon:"clock.fill") { selected = .orders }
                    Stat(title:"مكتمل", value: completed, color:.swissGreen, icon:"checkmark.circle.fill") { selected = .orders }
                    Stat(title:"مستعجل", value: store.orders.filter(\.urgent).count, color:.swissRed, icon:"exclamationmark.triangle.fill") { selected = .urgent }
                }
                VStack(alignment:.leading, spacing:12) {
                    Text("إجراءات سريعة").font(.headline)
                    Quick(title:"إضافة أوردر جديد", icon:"plus.circle.fill", color:.swissBlue) { selected = .add }
                    Quick(title:"البحث عن أوردر", icon:"magnifyingglass", color:.swissCyan) { selected = .search }
                    Quick(title:"الإحصائيات", icon:"chart.bar.fill", color:.swissPurple) { selected = .statistics }
                    Quick(title:"التقارير", icon:"doc.text.fill", color:.swissGreen) { selected = .reports }
                }.swissCard()
                if !store.orders.isEmpty {
                    VStack(alignment:.leading,spacing:10) { Text("آخر الأوردرات").font(.headline); ForEach(Array(store.orders.prefix(5))) { o in CompactOrder(order:o) } }.swissCard()
                }
            }.padding()
        }.background(Color.swissBG)
    }
    private var completed: Int { store.orders.filter { ["مكتمل","تم في الورشة","تم الاستبدال","تم هاتفيا"].contains($0.status) }.count }
    private func count(_ s:String)->Int { store.orders.filter{$0.status==s}.count }
    private var header: some View { HStack { VStack(alignment:.leading) { Text("SWISSMARK").font(.title2.bold()); Text("نظام إدارة الصيانة").font(.caption).foregroundStyle(.secondary) }; Spacer(); Image(systemName:"wrench.and.screwdriver.fill").font(.title).foregroundStyle(Color.swissBlue) }.foregroundStyle(Color.swissText).padding(4) }
}
struct Stat: View {
    let title:String; let value:Int; let color:Color; let icon:String; let action:()->Void
    var body: some View {
        Button(action: action) {
            VStack(alignment:.leading, spacing:8) {
                Image(systemName:icon).foregroundStyle(color)
                Text("\(value)").font(.system(size:28,weight:.bold))
                Text(title).font(.caption).foregroundStyle(.secondary)
            }.frame(maxWidth:.infinity, alignment:.leading).swissCard()
        }
    }
}
struct Quick: View { let title:String;let icon:String;let color:Color;let action:()->Void; var body:some View { Button(action:action){ HStack{Image(systemName:icon).foregroundStyle(color).frame(width:28);Text(title);Spacer();Image(systemName:"chevron.left").foregroundStyle(.secondary)}.foregroundStyle(.white) } } }
struct CompactOrder: View { let order:Order; var body: some View { HStack{VStack(alignment:.leading){Text("#\(order.orderNumber)").font(.headline);Text(order.customerName).font(.subheadline);Text(order.phone).font(.caption).foregroundStyle(.secondary)};Spacer();StatusBadge(status:order.status)}.padding(10).background(Color.swissBG.opacity(0.45)).clipShape(RoundedRectangle(cornerRadius:12)) } }
