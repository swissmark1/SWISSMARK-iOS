import SwiftUI

struct OrdersView: View {
    @EnvironmentObject var store: AppStore
    var urgentOnly = false
    @State private var selected: Order?
    @State private var status = "الكل"
    var filtered: [Order] { store.orders.filter { (urgentOnly ? $0.urgent : true) && (status == "الكل" || $0.status == status) } }
    var body: some View { ScrollView { VStack(spacing:12) {
        Picker("الحالة",selection:$status){Text("الكل").tag("الكل");ForEach(orderStatuses,id:\.self){Text($0).tag($0)}}.pickerStyle(.menu).frame(maxWidth:.infinity,alignment:.leading)
        ForEach(filtered){ order in OrderCard(order:order).onTapGesture{selected=order} }
        if filtered.isEmpty { EmptyState(text:"لا توجد أوردرات") }
    }.padding() }.background(Color.swissBG).sheet(item:$selected){OrderDetailView(order:$0)} }
}
struct OrderCard: View {
    let order: Order
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("#\(order.orderNumber)").font(.headline).foregroundStyle(Color.swissBlue)
                Spacer()
                if order.urgent {
                    Label("مستعجل", systemImage: "exclamationmark.triangle.fill")
                        .font(.caption.bold()).foregroundStyle(Color.swissRed)
                }
                StatusBadge(status: order.status)
            }
            Divider().opacity(0.25)
            Text(order.customerName).font(.title3.bold())
            HStack {
                Label(order.phone, systemImage: "phone.fill")
                Spacer()
                Label(order.region, systemImage: "mappin")
            }.font(.caption).foregroundStyle(.secondary)
            HStack {
                Info(title: "الجهاز", value: order.device)
                Info(title: "العطل", value: order.faultType)
            }
            Text(format(order.dateAdded)).font(.caption2).foregroundStyle(.secondary)
        }
        .foregroundStyle(Color.swissText)
        .swissCard()
        .buttonStyle(.plain)
    }
}
struct Info:View{let title:String;let value:String;var body:some View{VStack(alignment:.leading){Text(title).font(.caption2).foregroundStyle(.secondary);Text(value.isEmpty ? "-":value).font(.caption)}}}

struct OrderDetailView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    @State var order: Order
    @State private var editing = false
    @State private var showDelete = false
    var body: some View { NavigationStack { ScrollView { VStack(spacing:14) {
        HStack{Text("#\(order.orderNumber)").font(.title.bold());Spacer();StatusBadge(status:order.status)}.swissCard()
        section("بيانات الزبون", ["اسم الزبون":order.customerName,"الهاتف":order.phone,"الهاتف الثاني":order.secondPhone,"المنطقة":order.region])
        section("بيانات الصيانة", ["الجهاز":order.device,"نوع العطل":order.faultType,"الفني / الوكيل":order.agent,"تاريخ الإضافة":format(order.dateAdded)])
        section("الحالة", ["الحالة الحالية":order.status,"أجور الصيانة":order.maintenanceFee == 0 ? "-" : String(format:"%.2f",order.maintenanceFee),"الموقع":order.customerLocation.isEmpty ? "-" : order.customerLocation])
        if !order.notes.isEmpty { section("الملاحظات", ["":order.notes]) }
        VStack(spacing:10){Text("تغيير الحالة").font(.headline).frame(maxWidth:.infinity,alignment:.leading);ScrollView(.horizontal,showsIndicators:false){HStack{ForEach(orderStatuses,id:\.self){s in Button(s){order.status=s;Task{try? await store.update(order)}}.buttonStyle(.bordered).tint(s == order.status ? Color.swissBlue : Color.gray)}}}}.swissCard()
        Button(role:.destructive){showDelete=true}label:{Label("حذف الأوردر",systemImage:"trash").frame(maxWidth:.infinity)}.buttonStyle(.bordered)
    }.padding() }.background(Color.swissBG).navigationTitle("تفاصيل الأوردر").navigationBarTitleDisplayMode(.inline).toolbar{ToolbarItem(placement:.topBarTrailing){Button("تم"){dismiss()}}}.alert("حذف الأوردر؟",isPresented:$showDelete){Button("حذف",role:.destructive){Task{try? await store.delete(order);dismiss()}};Button("إلغاء",role:.cancel){}} }
    }
    private func section(_ title: String, _ values: [String: String]) -> some View {
        let entries = values.sorted { $0.key < $1.key }
        return VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.headline)
            ForEach(Array(entries.enumerated()), id: \.offset) { _, entry in
                HStack {
                    if !entry.key.isEmpty {
                        Text(entry.key).foregroundStyle(.secondary)
                        Spacer()
                    }
                    Text(entry.value.isEmpty ? "-" : entry.value)
                        .multilineTextAlignment(.trailing)
                }
                Divider().opacity(0.2)
            }
        }
        .swissCard()
    }
}

struct AddOrderView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    @State private var order = Order()
    @State private var saving=false
    var body: some View { Form { Section("بيانات الزبون"){Field("اسم الزبون",$order.customerName);Field("الهاتف",$order.phone);Field("الهاتف الثاني",$order.secondPhone);Field("المنطقة",$order.region)};Section("بيانات الجهاز"){Field("الجهاز",$order.device);Field("نوع العطل",$order.faultType);Field("الفني / الوكيل",$order.agent)};Section("الموقع والملاحظات"){Field("الموقع",$order.customerLocation);TextField("الملاحظات",text:$order.notes,axis:.vertical).lineLimit(3...6)};Section{Button{saving=true;Task{do{try await store.addOrder(order);dismiss()}catch{}}}label:{HStack{Spacer();if saving{ProgressView()};Text("حفظ الأوردر").bold();Spacer()}}.disabled(saving)} }.scrollContentBackground(.hidden).background(Color.swissBG).navigationTitle("إضافة أوردر") }
}
func Field(_ title:String,_ value:Binding<String>)->some View{TextField(title,text:value)}

struct SearchView: View {
    @EnvironmentObject var store: AppStore
    @State private var q = ""
    @State private var selected: Order?

    private var results: [Order] {
        let query = q.lowercased()
        return store.orders.filter { order in
            order.customerName.lowercased().contains(query)
                || order.phone.lowercased().contains(query)
                || String(order.orderNumber).contains(query)
        }
    }

    var body: some View {
        VStack {
            TextField("اسم الزبون أو الهاتف أو رقم الأوردر", text: $q)
                .textFieldStyle(.roundedBorder)
                .padding()

            ScrollView {
                LazyVStack(spacing: 12) {
                    ForEach(results) { order in
                        OrderCard(order: order)
                            .onTapGesture {
                                selected = order
                            }
                    }
                }
                .padding(.horizontal)
            }
        }
        .background(Color.swissBG)
        .sheet(item: $selected) { order in
            OrderDetailView(order: order)
        }
    }
}

struct StatisticsView: View { @EnvironmentObject var store:AppStore;var body:some View{ScrollView{VStack(spacing:12){Stat(title:"إجمالي الأوردرات",value:store.orders.count,color:.swissBlue,icon:"list.clipboard.fill",action:{});ForEach(orderStatuses,id:\.self){s in HStack{Text(s);Spacer();Text("\(store.orders.filter{$0.status==s}.count)").bold()}.swissCard()}}.padding()}.background(Color.swissBG)}}
struct ReportsView: View { @EnvironmentObject var store:AppStore;var body:some View{ScrollView{VStack(alignment:.leading,spacing:14){Text("التقارير").font(.title2.bold());Text("الفترة الحالية").foregroundStyle(.secondary);ReportCard(title:"اليوم",count:store.orders.filter{Calendar.current.isDateInToday($0.dateAdded)}.count);ReportCard(title:"من 1 إلى 15",count:store.orders.filter{Calendar.current.component(.day,from:$0.dateAdded)<=15}.count);ReportCard(title:"من 16 إلى نهاية الشهر",count:store.orders.filter{Calendar.current.component(.day,from:$0.dateAdded)>=16}.count)}.padding()}.background(Color.swissBG)}}
struct ReportCard:View{let title:String;let count:Int;var body:some View{HStack{Image(systemName:"doc.text.fill").foregroundStyle(Color.swissGreen);Text(title);Spacer();Text("\(count) أوردر").bold()}.swissCard()}}
struct FeesView:View{@EnvironmentObject var store:AppStore;var total:Double{store.orders.reduce(0){$0+$1.maintenanceFee}};var body:some View{VStack(spacing:16){Text("إجمالي أجور الصيانة").font(.headline);Text(String(format:"%.2f",total)).font(.system(size:42,weight:.bold)).foregroundStyle(Color.swissGreen);ScrollView{ForEach(store.orders.filter{$0.maintenanceFee>0}){o in HStack{Text("#\(o.orderNumber)");Spacer();Text(String(format:"%.2f",o.maintenanceFee));}.swissCard()}}}.padding().frame(maxWidth:.infinity,maxHeight:.infinity).background(Color.swissBG)}}
struct SimpleFeatureView:View{let title:String;let icon:String;let description:String;var body:some View{VStack(spacing:18){Image(systemName:icon).font(.system(size:54)).foregroundStyle(Color.swissBlue);Text(title).font(.title.bold());Text(description).foregroundStyle(.secondary).multilineTextAlignment(.center);Text("هذه الشاشة جاهزة للربط مع وظائف النظام الأصلية.").font(.footnote).foregroundStyle(.secondary)}.padding().frame(maxWidth:.infinity,maxHeight:.infinity).background(Color.swissBG)}}
struct EmptyState:View{let text:String;var body:some View{VStack(spacing:8){Image(systemName:"tray").font(.largeTitle).foregroundStyle(.secondary);Text(text).foregroundStyle(.secondary)}.frame(maxWidth:.infinity).padding(40)}}
func format(_ d:Date)->String{let f=DateFormatter();f.dateFormat="yyyy-MM-dd";return f.string(from:d)}
